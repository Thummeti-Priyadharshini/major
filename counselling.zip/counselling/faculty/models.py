from django.db import models
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import UserManager
from django.dispatch import receiver
from django.db.models.signals import post_save

from django.contrib.auth.models import AbstractUser

# Create your models here.
'''class TSheets(models.Model):
    rollno = models.CharField(max_length=11)
    sem = models.IntegerField()
    subcode = models.CharField(max_length=10)
    gradepoint = models.FloatField()
    credits = models.FloatField()

    def __str__(self):
        return f"{self.rollno} - Sem {self.sem} - {self.subjectcode}"'''

class Result_m:
    subname:str
    mid1:int
    mid2:int
    average:int
class Result_s:
    seme:int
    sgpa:float
    cgpa:float
class Workshop:
    wtitle:str
    duration:str
    date:str
    wcn:str

class Placement:
    cname:str
    year:str
    pack:str

class Project:
    ptitle:str
    guide:str
    pdescription:str
    date:str

class PaperP:
    pptitle:str 
    ptype:str
    guide:str
    date:str

class Internship:
    title:str
    cn:str
    date:str
    end:str
class Achieve:
    achname:str
    date:str
class Certif:
    skill:str
    issue:str
    date:str
    
class P_det:
    rollno:str
    branch:str
    sname:str
    gender:str
    saadhaar:str
    smobile:str
    semail:str
    dob:str
    bgrp:str
    add_comm:str
    add_perm:str
    caste:str
    subcaste:str
    religion:str
    father:str
    mother:str
    focu:str
    mocu:str
    fdes:str
    mdes:str
    finc:str
    minc:str
    fmob:str
    mmob:str
    femail:str
    memail:str
    faad:str
    maad:str
    agg:float
    tbacklogs:str
class Education:
    schoolname:str
    board:str
    passoutyear:int
    percentage:int
class Branch:
    bid:int
    branch:str
class Roles:
    roleid:int
    rolename:str
class Faculty:
    empid:int
    firstname:str
    lastname:str
    email:str
    password:str
    roleid:int
    branch:int
    phonenumber:str
    gender:str
class Students:
    rollno:str
    fname:str
    lname:str
    email:str
    branch:str
    year:int
    semester:int
    studmob:str
    fmob:str
    section:str
    gpa:float
class Student:
    rollno:str
    password:str
    email:str


class Users:
    name:str
    rollno:str
    branch:str
    section:str
class Years:
    year:int
class Semester:
    sem:int
class Message:
    fname:str
    lname:str
    empid:int
    rollno:str
    subject:str
    message:str
    status:int
    date:str
    received:str
    r_id:int

