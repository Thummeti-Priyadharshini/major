from django.shortcuts import render, redirect
from django.http import HttpResponse
import mysql.connector
#from django.db.models import Sum, F, FloatField
from django.http import JsonResponse
from datetime import datetime
from django.forms.models import model_to_dict
from django.contrib import messages
from django.urls import reverse
from django.core.files.storage import FileSystemStorage
#from .forms import MyForm
import smtplib
import matplotlib.patches as mpatches
import numpy as np
import matplotlib.pyplot as plt
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from .models import *
# Create your views here.
from django.http import HttpResponse
import mysql.connector
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.csrf import ensure_csrf_cookie
@ensure_csrf_cookie
@csrf_exempt



def dashboard_student(request):
    conn = mysql.connector.connect(host="localhost",
            user="root",
            password="",
            database="studentdb")
    mycursor=conn.cursor()
    if "rollno_s" in request.session:
        roll = request.session.get("rollno_s")
        mycursor.execute ("select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section from students where rollno='"+roll+"' ")
        user_details = mycursor.fetchone()

        #mycursor.execute("select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section,attendance from students where branch='"+branch1+"' and year='"+year1+"' and semester='"+sem1+"' and section='"+section1+"' ORDER BY rollno")
        column_details = ['Rollno','Firstname','Lastname','Email','Branch','Year','Semester','Student Mobile','Father Mobile','Section']
        
        
        
        if user_details!=None:
            obj=Faculty()
            column_names = [column for column in column_details]
    
    # Create a list of tuples with column names and user details
            user_info = [(column_names[i], user_details[i]) for i in range(len(column_names))]
    
    
            
            
            return render(request, 'dashboard_student.html', {'user_info':user_info,'rollno_s':roll})
        
    else:
        return render(request, 'signin.html')


def edit_details_s(request):
    conn = mysql.connector.connect(host="localhost",
            user="root",
            password="",
            database="studentdb")
    mycursor=conn.cursor()

 #ADMIN_EDIT_DETAILS
    if "rollno_s" in request.session:
        if request.method=='POST':
            roll = request.session.get("rollno_s")
            try:
                email_new=request.POST['email']
            except ValueError:
                return redirect('logout_s')
            mycursor.execute ("select email from students where rollno='"+roll+"' ")
            result=mycursor.fetchone()
            email=result[0]

            pwd=request.POST['password']
            fname=request.POST['firstname']
            lname=request.POST['lastname']

            if email_new!=email:
                
                result=mycursor.execute ("UPDATE students SET email=%s, fname=%s, lname=%s WHERE rollno=%s", [email_new, fname, lname, roll])
                result=mycursor.execute ("UPDATE studentdetails SET email=%s,password=%s WHERE rollno=%s", [email_new, pwd, roll])
                conn.commit()
                return redirect('logout_s')
                #else:
                    #return redirect('edit_details')
            else:
                result=mycursor.execute ("UPDATE students SET  fname=%s, lname=%s WHERE rollno=%s", [fname, lname,  roll])
                conn.commit()
                result1=mycursor.execute ("UPDATE studentdetails SET password=%s WHERE rollno=%s", [pwd, roll])
                conn.commit()
                if result!=None and result1!=None:
                    messages.success(request, 'successfully updated')
    
                    return redirect('edit_details_s')
                else:
                    return redirect('dashboard_student')

        else:       
            roll = request.session.get("rollno_s")
            mycursor.execute ("select password from studentdetails where rollno='"+roll+"' ")
            result=mycursor.fetchone()
            
            column_details = ['email', 'firstname','lastname','password']
            mycursor.execute(f"SELECT email,fname,lname FROM students WHERE rollno='{roll}'")
            user_details = mycursor.fetchone()
            user_details=list(user_details)
        
            if user_details!=None:
                 obj=Faculty()
                 column_names = [column for column in column_details]
                 user_details.append(result[0])
    
    # Create a list of tuples with column names and user details
                 user_info = [(column_names[i], user_details[i]) for i in range(len(user_details))]
                 return render(request, 'edit_details_s.html', {'user_info':user_info,'rollno_s':roll})
        
    else:
        return render(request, 'signin.html')

def alloted_faculty(request):
    if 'rollno_s' in request.session:
        roll= request.session.get("rollno_s")
        conn=mysql.connector.connect(host="localhost", user="root", password="",database="studentdb")
        mycursor=conn.cursor()
        mycursor.execute("select semester,year,faculty from students where rollno=%s", (roll,))

        result=mycursor.fetchall()
        if result!=None:
            conn=mysql.connector.connect(host="localhost", user="root", password="",database="counsellingdb")
            mycursor=conn.cursor()
            details=[]
          
            for i in result:
                    mycursor.execute("select empid,firstname,lastname,email,phonenumber,branch,gender,roleid from faculty where empid=%s", (i[2],))
                    row=mycursor.fetchone()

            
                        
                    
                    if row!=None:
                                obj = Faculty()         
                                obj.empid = row[0]
                                obj.firstname = row[1]
                                obj.lastname=row[2]
                                obj.email = row[3]
                                obj.phonenumber = row[4]
                                obj.branch = row[5]
                                
                                obj.gender = row[6]
                               
                                obj.roleid = row[7]
                                obj.semester=i[0]
                                obj.year=i[1]
                                details.append(obj)
            return render(request,"alloted_faculty.html",{'details':details,'rollno_s':roll})
        else:
            return render(request,"edit_details_s.html",{'rollno_s':roll})




    else:

         return render(request,"signin.html")


def logout_s(request):
    rollno_s = request.session.get("rollno_s")
    del rollno_s
    request.session.modified = True
    return redirect('signin')
import datetime

# using now() to get current time

def message_s(request,x):
    if "rollno_s" in request.session:
        roll = request.session.get("rollno_s")
        if request.method=='POST':
            conn=mysql.connector.connect(host="localhost", user="root", password="", database= "counsellingdb")
            mycursor=conn.cursor()
             #mycursor.execute("SELECT MAX(empid) FROM faculty WHERE branch = %s", (branchid,))
            mycursor.execute("select firstname,lastname from faculty where empid= %s", (x,))
            
            r1 = mycursor.fetchone()
            now = datetime.datetime.now()

# Convert datetime object to string  
            now_str = now.strftime("%Y-%m-%d %H:%M:%S")
            #pwd=request.POST['password']
            subject=request.POST['subject']
            msg=request.POST['message']
            mycursor.execute("insert into messages(fname, lname, empid, rollno, subject, message, status, date, received,r_id) "
                             "values(%s, %s, %s, %s, %s, %s, '0', %s, %s,'1')",
                             (r1[0], r1[1], x, roll, subject, msg,now_str, roll))
            conn.commit()
            return render(request,'message_s.html',{'rollno_s':roll})
        else:
             return render(request,'message_s.html',{'rollno_s':roll})
    else:
             return render(request,'signin.html')









        
    
    
def view_message_s(request,x):
    if "rollno_s" in request.session:
        roll = request.session.get("rollno_s")
        conn=mysql.connector.connect(host="localhost", user="root", password="", database= "counsellingdb")
        mycursor=conn.cursor()
             #mycursor.execute("SELECT MAX(empid) FROM faculty WHERE branch = %s", (branchid,))
        mycursor.execute("select * from messages where received= %s", (roll,))
            
        r1 = mycursor.fetchall()
        if r1!=None:
                        
                        details = []
                        for row in r1:
                                obj = Message()         
                                #obj.rollno = row[0]
                                obj.fname = row[0]
                                obj.lname=row[1]
                                obj.empid = row[2]
                                obj.rollno = row[3]
                                obj.subject = row[4]
                                obj.message = row[5]
                                obj.status = row[6]
                                obj.date = row[7]
                                obj.received = row[8]
                                obj.r_id= row[9]
                                obj.id = row[10]
                                
                                details.append(obj)
                        return render(request, 'm_s_table.html', {'details':details,'rollno_s':roll})
        else:
            return render(request, 'alloted_faculty.html', {'rollno_s':roll})


        


    return render(request,'signin.html')
def unread(request,x,y):
    if "rollno_s" in request.session:
        roll = request.session.get("rollno_s")
        conn=mysql.connector.connect(host="localhost", user="root", password="", database= "counsellingdb")
        mycursor=conn.cursor()
        result=mycursor.execute ("UPDATE messages SET status='0' WHERE rollno=%s and id=%s and empid=%s ", [roll,y,x])
        conn.commit()
        if result!=None:
            return redirect('view_message_s',x=x) 
        else:
             return redirect('view_message_s',x=x) 
    else:
        return redirect('signin') 
def read(request,x,y):
    if "rollno_s" in request.session:
        roll = request.session.get("rollno_s")
        conn=mysql.connector.connect(host="localhost", user="root", password="", database= "counsellingdb")
        mycursor=conn.cursor()
        result=mycursor.execute ("UPDATE messages SET status='1' WHERE rollno=%s and id=%s and empid=%s ", [roll,y,x])
        conn.commit()
        if result!=None:
            return redirect('view_message_s',x=x) 
        else:
             return redirect('view_message_s',x=x) 
    else:
        return redirect('signin') 

def registration_details_s(request,sem1):
    if "rollno_s" in request.session:
        roll = request.session.get("rollno_s")
        if request.method=='POST':
                 return render(request,"semester_wise.html")
        else:
    
            conn=mysql.connector.connect(host="localhost", user="root", password="", database= "studentdb")
            mycursor=conn.cursor()
            #sem1=request.POST['sem1']
            #SSC AND COLLEGE DETAILS
           
            column_details=['schoolname','board','passoutyear','percentage']
            education_type = 'SSC'
            query = "SELECT schoolname, board, passoutyear, percentage FROM education WHERE rollno = %s AND education = %s"
            params = (roll, education_type)
            mycursor.execute(query, params)
            ssc = mycursor.fetchone()
            if ssc!=None:
                  user_info_ssc = [(column_details[i], ssc[i]) for i in range(len(ssc))]
            else:
                user_info_ssc=None

# Retrieve college details
            education_type = 'INTER/DIPLOMA'
            query = "SELECT schoolname, board, passoutyear, percentage FROM education WHERE rollno = %s AND education = %s"
            params = (roll, education_type)
            mycursor.execute(query, params)
            college = mycursor.fetchone()
            if college!=None:
                   user_info_college = [(column_details[i], college[i]) for i in range(len(college))]
            else:
                user_info_college=None
  # PERSONAL DETAILS
            column_details=['rollno', 'branch', 'student-name', 'gender', 'student-aadhaar', 'student-mobile', 'student-email', 'date-of-birth', 'blood-group', 'address_temporary', 'address_permanent', 'caste', 'subcaste', 'religion', 'father-name', 'mother-name', 'father-occupation', 'mother-occupation', 'father-designation', 'mother-designation', 'father-income', 'mother-income', 'father-mobile', 'mother-mobile', 'father-email', 'mother-email', 'father-aadhar', 'mother-aadhar', 'aggregrate', 'Total-backlogs']
            
            query = f"SELECT rollno,branch, sname, gender, saadhaar, smobile, semail, dob, bgrp, add_comm, add_perm, caste, subcaste, religion, father, mother, focu, mocu, fdes, mdes, finc, minc, fmob, mmob, femail, memail, faad, maad, agg, tbacklogs FROM student WHERE rollno = '{roll}' "
            
            mycursor.execute(query)
            p_det = mycursor.fetchone()
            if p_det!=None:
                 user_info_p_det = [(column_details[i], p_det[i]) for i in range(len(p_det))]
            else:
                user_info_p_det=None

#CERTIFICATIONS
            certif_details=['Certification_Name','Issued-By','Date-of-Issue']
            
            query = "SELECT skill,issue,date FROM certification WHERE rollno = %s"
            params=(roll,)
           
            mycursor.execute(query,params)
            certi = mycursor.fetchall()
            if certi!=None:
               certif=[]
               for i in certi:
                  obj=Certif()
                  obj.skill=i[0]
                  obj.issue=i[1]
                  obj.date=i[2]
                  certif.append(obj)
            else:
                certif_details=None
                certif=None
# ACHIEVEMENTS
            achieve_details=['Achievement_Name','Date-of-Issue']
            
            query = "SELECT achname,date FROM achieve WHERE rollno = %s "
            params=(roll,)
           
            mycursor.execute(query,params)
            achieve = mycursor.fetchall()
            if achieve!=None:
               achieves=[]
               for i in achieve:
                  obj=Achieve()
                  obj.achname=i[0]
                  #obj.issue=i[1]
                  obj.date=i[1]
                  achieves.append(obj)
            else:
                achieve_details=None
                achieves=None
#INTERNSHIPS
            intern_details=['Title','Company-Name','Date-of-start','End-Date']
            
            query = "SELECT title,cn,date,end FROM internship WHERE rollno = %s"
            params=(roll,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            intern = mycursor.fetchall()
            if intern!=None:
               interns=[]
               for i in intern:
                  obj=Internship()
                  obj.title=i[0]
                  obj.cn=i[1]
                  obj.date=i[2]
                  obj.end=i[3]
                  interns.append(obj)
            else:
                intern_details=None
                interns=None

#PAPER PRESENTATIONS
            paper_details=['Paper-Title','Paper-Type','Guide','Date']
            
            query = "SELECT pptitle,ptype,guide,date FROM paperpresentations WHERE rollno = %s"
            params=(roll,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            pp = mycursor.fetchall()
            if pp!=None:
               pps=[]
               for i in pp:
                  obj=PaperP()
                  obj.pptitle=i[0]
                  obj.ptype=i[1]
                  obj.guide=i[2]
                  obj.date=i[3]
                  pps.append(obj)
            else:
                paper_details=None
                pps=None


#PROJECTS
            project_details=['Project-Title','Guide','Project Description','Date']
            
            query = "SELECT ptitle,guide,pdescription,date FROM projects WHERE rollno = %s"
            params=(roll,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            p = mycursor.fetchall()
            if p!=None:
               pr=[]
               for i in p:
                  obj=Project()
                  obj.ptitle=i[0]
                  obj.guide=i[1]
                  obj.pdescription=i[2]
                  obj.date=i[3]
                  pr.append(obj)
            else:
                project_details=None
                pr=None

#PLACEMENTS
            place_details=['Company-Name','Year','Package']
            
            query = "SELECT cname,year,pack FROM place WHERE rollno = %s"
            params=(roll,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            p = mycursor.fetchall()
            if p!=None:
               pla=[]
               for i in p:
                  obj=Placement()
                  obj.cname=i[0]
                  obj.year=i[1]
                  obj.pack=i[2]
                  #obj.date=i[3]
                  pla.append(obj)
            else:
                place_details=None
                pla=None


#workshops  
            w_details=['Workshop-Title','Duration-in-Days','Date','Conducted-By']
            
            query = "SELECT wtitle,duration,date,wcn FROM workshops WHERE rollno = %s"
            params=(roll,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            w = mycursor.fetchall()
            if w!=None:
               work=[]
               for i in w:
                  obj=Workshop()
                  obj.wtitle=i[0]
                  obj.duration=i[1]
                  obj.date=i[2]
                  obj.wcn=i[3]
                  work.append(obj)
            else:
                w_details=None
                work=None

#gpa        SELECT sem, COUNT(*) AS count, SUM(credits * 10) AS total_credits FROM tsheets WHERE rollno = '19281A0562' AND credits > 0 GROUP BY sem;
            
                  
            
            query  = "SELECT rollno, sem, ROUND(SUM(gradepoint * credits) / SUM(credits), 2) AS sgpa FROM tsheets WHERE rollno = '"+roll+"' and credits>0 GROUP BY rollno, sem;"
           
           
            mycursor.execute(query)
            result=mycursor.fetchall()
            if result!=None:


                for i in result:
                     q  = "SELECT SUM(gradepoints*credits)  FROM tsheets WHERE rollno ='"+roll+"' AND sem='i[0]' GROUP BY sem"
           



    
        
            
            return render(request,"registration_details_s.html",{'place_details':place_details,'pla':pla,'w_details':w_details,'work':work,'project_details':project_details,'pr':pr,'paper_details':paper_details,'pps':pps,'intern_details':intern_details,'interns':interns,'user_info_college':user_info_college,'user_info_p_det':user_info_p_det,'user_info_ssc':user_info_ssc,'certif_details':certif_details,'certif':certif,'achieve_details':achieve_details,'achieves':achieves,'rollno_s':roll})
        
        
        
    
    
            
            
          
    else:        

        return render(request,"signin.html")

def performance_s(request,sem1,roll):
    if "rollno_s" in request.session:
        roll=request.session.get("rollno_s")
        if request.method=='POST':
            t=request.POST.get('type',None)
            conn = mysql.connector.connect(host="localhost", user="root", password="",database="studentdb")
            mycursor = conn.cursor()
            query  = "SELECT fname,lname FROM students WHERE rollno = '"+roll+"'"
            mycursor.execute(query)
            result1=mycursor.fetchone()
            if result1!=None:
                  name=result1[0]+" "+result1[1]
            else:
                return  render(request,'performance_f.html',{'rollno_s':roll})

            query  = "SELECT  sem, CASE WHEN SUM(CASE WHEN grade = 'F' OR gradepoint = 0 THEN 1 ELSE 0 END) > 0 THEN 1 ELSE ROUND(SUM(gradepoint * credits) / SUM(credits), 2) END AS sgpa, CASE WHEN SUM(CASE WHEN grade = 'F' OR gradepoint = 0 THEN 1 ELSE 0 END) > 0 THEN 1 ELSE ROUND(AVG(SUM(gradepoint * credits) / SUM(credits)) OVER (PARTITION BY rollno ORDER BY sem), 2) END AS cgpa FROM tsheets WHERE rollno = '"+roll+"' GROUP BY rollno, sem;"
            mycursor.execute(query)
            result=mycursor.fetchall()
            query1  = "SELECT t1.subname as subname, t1.marks AS mid1, COALESCE(t2.marks, 0) AS mid2, CASE WHEN t2.marks IS NULL THEN 0 ELSE round((t1.marks + t2.marks)/2) END AS average FROM mids t1 LEFT JOIN mids t2 ON t1.rollno = t2.rollno AND t1.subname = t2.subname AND t2.mid_no = '2' WHERE t1.rollno = '"+roll+"' AND t1.mid_no = '1';"
            
            mycursor.execute(query1)
            result1=mycursor.fetchall()
            
            
            #k=result2[0]
            
            query3 = "SELECT attendance from students WHERE rollno = '"+roll+"' and semester='"+str(sem1)+"'"
            
            mycursor.execute(query3)
            result3=mycursor.fetchone()
            if result3!=None:
               y=result3[0]
            else:
                attendance=None
            
            if result!=None and result1!=None:

                
                sem=[]
                for x in result:
                         obj=Result_s()
                         obj.seme=x[0]
                         obj.sgpa=x[1]
                         obj.cgpa=x[2]
                        
                         sem.append(obj)
                mid=[]
                for x in result1:
                        obj=Result_m()
                        obj.subname=x[0]
                        obj.mid1=x[1]
                        obj.mid2=x[2]
                        obj.average=x[3]
                        mid.append(obj)
                if t=='table':
                    if len(sem)<=0:
                        sem=None
                    if len(mid)<=0:
                        mid=None
                    if y==0:
                        y=None


                    return  render(request,'tables_f.html',{'rollno_s':roll,'name':name,'sem':sem,'mid':mid,'y':y})
                elif t=='graph':
                    seme = [result.seme for result in sem]
                    sgpa = [result.sgpa for result in sem]
                    
                    colors = []
                    for value in sgpa:
                        if value == 1.00:
                           colors.append('red')
                        elif value > 9.00:
                            colors.append('green')
                        else:
                            colors.append('blue')


    # Map each semester to a color from the color map

    # Barplot for sgpa
                    
    
                    if len(seme)>0 and len(sgpa)>0:
                        fig, ax = plt.subplots(figsize=(8, 6))
                   
                        x=ax.bar(seme, sgpa ,color=colors)

                        ax.set_xlabel('Semester')
                        ax.set_ylabel('Semester GPA')
                        ax.set_title('Semester Results')
                        ax.set_ylim(0, 10)
                        for rect in x:
                            height = rect.get_height()
                            if height == 1:
                                plt.text(rect.get_x() + rect.get_width() / 2.0, height, '0', ha='center', va='bottom')
                            else:
                                plt.text(rect.get_x() + rect.get_width() / 2.0, height, f'{height:.2f}', ha='center', va='bottom')
                    
                        red_patch = mpatches.Patch(color='red', label='Backlogs')
                        blue_patch = mpatches.Patch(color='blue', label='No Backlogs')
                        green_patch= mpatches.Patch(color='green', label='Above 9.0 sgpa')
                    
                        ax.legend(handles=[red_patch, blue_patch,green_patch], bbox_to_anchor=(1.05, 1), loc='upper left')
                        graph_file1 = 'semester_results_1.png'
                        fig.savefig('C:/external/counselling/static/image/'+ graph_file1,bbox_inches='tight')
                    else:
                        graph_file1 = None
                        #fig.savefig('C:/external/counselling/static/image/'+ graph_file1,bbox_inches='tight')
    
    # Convert the graph to an HTML string
    # line plot for cgpa
                
                    cgpa = [result.cgpa for result in sem]
                    colors = []
                    for value in cgpa:
                        if value <= 1.00:
                           colors.append('red')
                        else:
                           colors.append('#B2BEB5')
                  
    
                    if len(cgpa)>0:
                        
                        fig2, ax2 = plt.subplots()
                        ax2.plot(seme, cgpa, marker='o', markersize=5, color='blue', label='No Backlogs')
                        ax2.plot(seme, cgpa, marker='o', markersize=5, color='red', label='Have Backlogs')
                        ax2.plot(seme, cgpa, marker='o', markersize=5, color='green', label='Above 9.0 cgpa')
                        for i in range(len(seme)-1):
                            if cgpa[i] == 1:
                                ax2.plot([seme[i], seme[i+1]], [cgpa[i], cgpa[i+1]], color='black')
                                ax2.plot(seme[i], cgpa[i], marker='o', markersize=5, color='red')
                                ax2.annotate('0', xy=(seme[i], cgpa[i]), xytext=(seme[i]+0.1, cgpa[i]+0.1), fontsize=10,ha='left', va='bottom')
                            elif cgpa[i]<9:
    
                                ax2.plot([seme[i], seme[i+1]], [cgpa[i], cgpa[i+1]], color='black')
                                ax2.plot(seme[i], cgpa[i], marker='o', markersize=5, color='blue')
                                ax2.annotate(f'{cgpa[i]:.2f}', xy=(seme[i], cgpa[i]), xytext=(seme[i], cgpa[i]), fontsize=10,ha='left', va='bottom')
                            else:
                                ax2.plot([seme[i], seme[i+1]], [cgpa[i], cgpa[i+1]], color='black')
                                ax2.plot(seme[i], cgpa[i], marker='o', markersize=5, color='green')
                                ax2.annotate(f'{cgpa[i]:.2f}', xy=(seme[i], cgpa[i]), xytext=(seme[i], cgpa[i]), fontsize=10,ha='left', va='bottom')
                    
                        if cgpa[-1] == 1:
                           ax2.plot(seme[-1], cgpa[-1], marker='o', markersize=5, color='red')
                           ax2.annotate(0, xy=(seme[-1], cgpa[-1]), xytext=(seme[-1], cgpa[-1]), fontsize=10,ha='left', va='bottom')
                        elif cgpa[-1]<9:
                            ax2.plot(seme[-1], cgpa[-1], marker='o', markersize=5, color='blue')
                            ax2.annotate(f'{cgpa[-1]:.2f}', xy=(seme[-1], cgpa[-1]), xytext=(seme[-1], cgpa[-1]), fontsize=10,ha='left', va='bottom')
                        else:
                            ax2.plot(seme[-1], cgpa[-1], marker='o', markersize=5, color='green')
                            ax2.annotate(f'{cgpa[-1]:.2f}', xy=(seme[-1], cgpa[-1]), xytext=(seme[-1], cgpa[-1]), fontsize=10,ha='left', va='bottom')
                        ax2.set_title('CGPA based results')
                        ax2.legend(loc='center left', bbox_to_anchor=(1, 0.5))

                        graph_file2 = 'semester_results_2.png'
                        fig2.savefig('C:/external/counselling/static/image/'+ graph_file2,bbox_inches='tight')
                    else:
                        graph_file2=None


        #midmarks
                    subname = [x.subname for x in mid]
                    mid1 = [x.mid1 for x in mid]
                    mid2 = [x.mid2 for x in mid]
                    avg = [x.average for x in mid]   
                    if len(mid1)>0 and len(subname)>0 and len(mid2)>0 and len(avg)>0:
                        plt.figure(figsize=(10, 6))
                        plt.style.use('ggplot')
                        bar_width = 0.35
                    #plt.xticks([r + bar_width / 2 for r in range(len(subname))], subname)
                        r1 = [x * 3 for x in range(len(subname))]
                        r2 = [x * 3 + 1 for x in range(len(subname))]
                        r3 = [x * 3 + 2 for x in range(len(subname))]
                    
                        bar_spacing = 0.05

# set x-tick locations for each bar group
                    

                        for i in range(len(mid)):
                            num_ticks = 10
                            xtick_locations = np.arange(num_ticks) * bar_width + r2[i] - bar_width / 2
                            #if i % 3 == 0:
                                  #plt.xticks([r + bar_width for r in range(i, i+3)], subname[i:i+3])
                            if avg[i] <14:
                                plt.bar(r1[i], mid1[i], color='blue', width=bar_width, edgecolor='black', label='Mid1')
                                plt.bar(r2[i], mid2[i], color='orange', width=bar_width, edgecolor='black', label='Mid2')
                                plt.bar(r3[i], avg[i], color='red', width=bar_width, edgecolor='black', label='average')
                            else:
                                 plt.bar(r1[i], mid1[i], color='blue', width=bar_width, edgecolor='black', label='Mid1')
                                 plt.bar(r2[i], mid2[i], color='orange', width=bar_width, edgecolor='black', label='Mid2')
                                 plt.bar(r3[i], avg[i], color='green', width=bar_width, edgecolor='black', label='average')
                            plt.text(r1[i], mid1[i], str(mid1[i]), ha='center', va='bottom', fontsize=10)
                            plt.text(r2[i], mid2[i], str(mid2[i]), ha='center', va='bottom', fontsize=10)
                            plt.text(r3[i], avg[i], str(avg[i]), ha='center', va='bottom', fontsize=10)
                        plt.xlabel('Subjects')
                        plt.ylabel('Marks')
                        plt.title('Mid-term Marks')
                        plt.xticks([r*3 + bar_width+1 for r in range(len(subname))], subname)


                    

                        for i in range(0, len(subname)*3, 3):
                                plt.axvline(x=i-0.5, color='black', linewidth=3)
                        red_patch = mpatches.Patch(color='red', label='Fail')
                        blue_patch = mpatches.Patch(color='blue', label='Mid1')
                        orange_patch= mpatches.Patch(color='orange', label='Mid2')
                        green_patch= mpatches.Patch(color='green', label='good average')
                    
                        plt.legend(handles=[red_patch, blue_patch,orange_patch,green_patch], bbox_to_anchor=(1.05, 1), loc='upper left')
                        graph_file3 = 'mid_marks.png'
                        plt.savefig('C:/external/counselling/static/image/'+ graph_file3,bbox_inches='tight')
                    else:
                        graph_file3=None
         #ATTENDANCE
                    
                    percentage_attendance = y / 100.0

# calculate the percentage of absences
                    percentage_absences = 1 - percentage_attendance

# create a list of attendance and absences percentages
                    attendance_percentages = [percentage_attendance, percentage_absences]

# create a list of labels for the pie chart
                    labels = ['present', 'Absence']

# set the colors for the pie chart
                    if y>75:
                          colors = ['green', 'wheat']
                    elif y<75 and y>65:
                        colors = ['yellow', 'wheat']
                    else:
                        colors = ['red', 'wheat']


# create the pie chart
                    fig3, ax3 = plt.subplots()
                    ax3.pie(attendance_percentages, colors=colors, labels=labels, autopct='%1.1f%%', startangle=90)
                    red_patch = mpatches.Patch(color='red', label='<65%')
                    blue_patch = mpatches.Patch(color='yellow', label='<75% & >65%')
                    green_patch= mpatches.Patch(color='green', label='>75%')
                    
                    plt.legend(handles=[red_patch, blue_patch,green_patch], bbox_to_anchor=(1.05, 1), loc='upper left')
                    graph_file4 = 'attend.png'
                    f='Attendance of semester:'+" "+str(sem1)

                    ax3.set_title(f)
                    fig3.savefig('C:/external/counselling/static/image/'+ graph_file4,bbox_inches='tight')
                    if y<=0:
                        graph_file4=None


                    
    
                
                    return render(request, 'graphs_f.html', {'graph_file4':graph_file4,'graph_file3':graph_file3,'graph_file1': graph_file1,'graph_file2':graph_file2,'name':name,'rollno_s':roll})
                else:
                     return  render(request,'performance_f.html',{'rollno_s':roll})



            else:
                return  render(request,'performance_f.html',{'rollno_s':roll})
    





        else:
            return  render(request,'performance_f.html',{'rollno_s':roll})
    else:
        return  render(request,'signin.html')


def tables_s(request):
    return render(request,"tables_s.html")
def graphs_s(request):
    return render(request,"graphs_s.html")
 
                

            # Handle other cases
          

def semester_wise(request):
     if "rollno_s" in request.session:
        roll=request.session.get("rollno_s")
        if request.method=='POST':
            sem1=request.POST.get('sem1',None)
            ty=request.POST.get('type',None)
            if ty=='registration':
                 return render(request,'registration_details_s.html', {'sem1':sem1,'rollno_s':roll})
            elif ty=='performance':
                return render(request,'performance_s.html', {'sem1':sem1,'rollno_s':roll})
            else:

                return render(request,'semester_wise.html',{'rollno_s':roll})
        else:
            conn=mysql.connector.connect(host="localhost", user="root", password="", database= "counsellingdb")
            mycursor=conn.cursor()
            mycursor.execute("select * from semester")
            result=mycursor.fetchall()
            sem=[]  
            for x in result:
                 obj=Semester()
                 obj.sem=x[0]
                 sem.append(obj)
            return  render(request,'semester_wise.html',{'sem':sem,'rollno_s':roll})
            





