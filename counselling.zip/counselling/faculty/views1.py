from django.shortcuts import render, redirect
from django.http import HttpResponse
import mysql.connector
#from django.db.models import Sum, F, FloatField
from django.http import JsonResponse
from datetime import datetime
from django.forms.models import model_to_dict
from django.contrib import messages
from django.urls import reverse
from django.core.files.storage import FileSystemStorage
#from .forms import MyForm
import smtplib
import matplotlib.patches as mpatches
import numpy as np
import matplotlib.pyplot as plt
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from .models import *
# Create your views here.
from django.http import HttpResponse
import mysql.connector
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.csrf import ensure_csrf_cookie
@ensure_csrf_cookie
@csrf_exempt
def dashboard_faculty(request):
    conn = mysql.connector.connect(host="localhost",
            user="root",
            password="",
            database="counsellingdb")
    mycursor=conn.cursor()
    if "email_f" in request.session:
        email = request.session.get("email_f")
        mycursor.execute ("select * from faculty where email='"+email+"' ")
        result=mycursor.fetchone()
        mycursor.execute("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'faculty'")
        column_details = mycursor.fetchall()
        mycursor.execute(f"SELECT * FROM faculty WHERE email='{email}'")
        user_details = mycursor.fetchone()
        
        if user_details!=None:
            obj=Faculty()
            column_names = [column[0] for column in column_details]
    
    # Create a list of tuples with column names and user details
            user_info = [(column_names[i], user_details[i]) for i in range(len(column_names))]
    
    
            
            
            return render(request, 'dashboard_faculty.html', {'user_info':user_info,'email_f':email})
        
    else:
        return render(request, 'signin.html')
def edit_details_f(request):
    conn = mysql.connector.connect(host="localhost",
            user="root",
            password="",
            database="counsellingdb")
    mycursor=conn.cursor()

 #ADMIN_EDIT_DETAILS
    if "email_f" in request.session:
        if request.method=='POST':
            email_f = request.session.get("email_f")
            try:
                email_new=request.POST['email']
            except ValueError:
                return redirect('logout_a')

            pwd=request.POST['password']
            fname=request.POST['firstname']
            lname=request.POST['lastname']
            if email_new!=email_f:
                
                result=mycursor.execute ("UPDATE faculty SET email=%s, firstname=%s, lastname=%s, password=%s WHERE email=%s", [email_new, fname, lname, pwd, email_f])
                conn.commit()
                
                return redirect('logout_a')
                #else:
                    #return redirect('edit_details')
            else:
                result=mycursor.execute ("UPDATE faculty SET email=%s, firstname=%s, lastname=%s, password=%s WHERE email=%s", [email_new, fname, lname, pwd, email_f])
                conn.commit()
                if result!=None:
                    messages.success(request, 'successfully updated')
    
                    return redirect('edit_details_f')
                else:
                    return redirect('dashboard_faculty')

        else:       
            email_f = request.session.get("email_f")
            mycursor.execute ("select * from faculty where email='"+email_f+"' ")
            result=mycursor.fetchone()
            
            column_details = ['email', 'firstname','lastname','password']
            mycursor.execute(f"SELECT email,firstname,lastname,password FROM faculty WHERE email='{email_f}'")
            user_details = mycursor.fetchone()
        
            if user_details!=None:
                 obj=Faculty()
                 column_names = [column for column in column_details]
    
    # Create a list of tuples with column names and user details
                 user_info = [(column_names[i], user_details[i]) for i in range(len(user_details))]
                 return render(request, 'edit_details_f.html', {'user_info':user_info,'email_f':email_f})
        
    else:
        return render(request, 'signin.html')

def alloted_f(request):
    if 'email_f' in request.session:
        email = request.session.get("email_f")
        conn=mysql.connector.connect(host="localhost", user="root", password="",database="counsellingdb")
        mycursor=conn.cursor()
        mycursor.execute("select empid from faculty where email=%s", (email,))

        result=mycursor.fetchone()
        if result!=None:
            conn=mysql.connector.connect(host="localhost", user="root", password="",database="studentdb")
            mycursor=conn.cursor()
            mycursor.execute(f"select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section,attendance from students where faculty={result[0]} ORDER BY rollno")
            result=mycursor.fetchall()
            if result!=None:
                        
                        details = []
                        for row in result:
                                obj = Students()         
                                obj.rollno = row[0]
                                obj.fname = row[1]
                                obj.lname=row[2]
                                obj.email = row[3]
                                obj.branch = row[4]
                                obj.year = row[5]
                                obj.semester = row[6]
                                obj.studmob = row[7]
                                obj.fmob = row[8]
                                obj.section = row[9]
                                obj.attendance = row[10]
                                #obj.gpa = row[10]
                                
                                details.append(obj)
                        return render(request,"alloted_f.html",{'details':details,'email_f':email})
        else:
            return render(request,"edit_details_f.html",{'email_f':email})




    else:

         return render(request,"signin.html")


def logout_f(request):
    email_f = request.session.get("email_f")
    del email_f
    request.session.modified = True
    return redirect('signin')
    
def registration_details_f(request,rollno):
    if "email_f" in request.session:
        email = request.session.get("email_f")
        #mycursor.execute(" from faculty where email='{email}'")
        if request.method=='POST':
            return render(request,"registration_details_f.html")

        else:
            conn=mysql.connector.connect(host="localhost", user="root", password="", database= "studentdb")
            mycursor=conn.cursor()
            #SSC AND COLLEGE DETAILS
            column_details=['schoolname','board','passoutyear','percentage']
            education_type = 'SSC'
            query = "SELECT schoolname, board, passoutyear, percentage FROM education WHERE rollno = %s AND education = %s"
            params = (rollno, education_type)
            mycursor.execute(query, params)
            ssc = mycursor.fetchone()
            if ssc!=None:
                  user_info_ssc = [(column_details[i], ssc[i]) for i in range(len(ssc))]
            else:
                user_info_ssc=None

# Retrieve college details
            education_type = 'INTER/DIPLOMA'
            query = "SELECT schoolname, board, passoutyear, percentage FROM education WHERE rollno = %s AND education = %s"
            params = (rollno, education_type)
            mycursor.execute(query, params)
            college = mycursor.fetchone()
            if college!=None:
                   user_info_college = [(column_details[i], college[i]) for i in range(len(college))]
            else:
                user_info_college=None
  # PERSONAL DETAILS
            column_details=['rollno', 'branch', 'student-name', 'gender', 'student-aadhaar', 'student-mobile', 'student-email', 'date-of-birth', 'blood-group', 'address_temporary', 'address_permanent', 'caste', 'subcaste', 'religion', 'father-name', 'mother-name', 'father-occupation', 'mother-occupation', 'father-designation', 'mother-designation', 'father-income', 'mother-income', 'father-mobile', 'mother-mobile', 'father-email', 'mother-email', 'father-aadhar', 'mother-aadhar', 'aggregrate', 'Total-backlogs']
            
            query = f"SELECT rollno,branch, sname, gender, saadhaar, smobile, semail, dob, bgrp, add_comm, add_perm, caste, subcaste, religion, father, mother, focu, mocu, fdes, mdes, finc, minc, fmob, mmob, femail, memail, faad, maad, agg, tbacklogs FROM student WHERE rollno = '{rollno}' "
            
            mycursor.execute(query)
            p_det = mycursor.fetchone()
            if p_det!=None:
                 user_info_p_det = [(column_details[i], p_det[i]) for i in range(len(p_det))]
            else:
                user_info_p_det=None

#CERTIFICATIONS
            certif_details=['Certification_Name','Issued-By','Date-of-Issue']
            
            query = "SELECT skill,issue,date FROM certification WHERE rollno = %s "
            params=(rollno,)
           
            mycursor.execute(query,params)
            certi = mycursor.fetchall()
            if certi!=None:
               certif=[]
               for i in certi:
                  obj=Certif()
                  obj.skill=i[0]
                  obj.issue=i[1]
                  obj.date=i[2]
                  certif.append(obj)
            else:
                certif_details=None
                certif=None
# ACHIEVEMENTS
            achieve_details=['Achievement_Name','Date-of-Issue']
            
            query = "SELECT achname,date FROM achieve WHERE rollno = %s "
            params=(rollno,)
           
            mycursor.execute(query,params)
            achieve = mycursor.fetchall()
            if achieve!=None:
               achieves=[]
               for i in achieve:
                  obj=Achieve()
                  obj.achname=i[0]
                  #obj.issue=i[1]
                  obj.date=i[1]
                  achieves.append(obj)
            else:
                achieve_details=None
                achieves=None
#INTERNSHIPS
            intern_details=['Title','Company-Name','Date-of-start','End-Date']
            
            query = "SELECT title,cn,date,end FROM internship WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            intern = mycursor.fetchall()
            if intern!=None:
               interns=[]
               for i in intern:
                  obj=Internship()
                  obj.title=i[0]
                  obj.cn=i[1]
                  obj.date=i[2]
                  obj.end=i[3]
                  interns.append(obj)
            else:
                intern_details=None
                interns=None

#PAPER PRESENTATIONS
            paper_details=['Paper-Title','Paper-Type','Guide','Date']
            
            query = "SELECT pptitle,ptype,guide,date FROM paperpresentations WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            pp = mycursor.fetchall()
            if pp!=None:
               pps=[]
               for i in pp:
                  obj=PaperP()
                  obj.pptitle=i[0]
                  obj.ptype=i[1]
                  obj.guide=i[2]
                  obj.date=i[3]
                  pps.append(obj)
            else:
                paper_details=None
                pps=None


#PROJECTS
            project_details=['Project-Title','Guide','Project Description','Date']
            
            query = "SELECT ptitle,guide,pdescription,date FROM projects WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            p = mycursor.fetchall()
            if p!=None:
               pr=[]
               for i in p:
                  obj=Project()
                  obj.ptitle=i[0]
                  obj.guide=i[1]
                  obj.pdescription=i[2]
                  obj.date=i[3]
                  pr.append(obj)
            else:
                project_details=None
                pr=None

#PLACEMENTS
            place_details=['Company-Name','Year','Package']
            
            query = "SELECT cname,year,pack FROM place WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            p = mycursor.fetchall()
            if p!=None:
               pla=[]
               for i in p:
                  obj=Placement()
                  obj.cname=i[0]
                  obj.year=i[1]
                  obj.pack=i[2]
                  #obj.date=i[3]
                  pla.append(obj)
            else:
                place_details=None
                pla=None


#workshops  
            w_details=['Workshop-Title','Duration-in-Days','Date','Conducted-By']
            
            query = "SELECT wtitle,duration,date,wcn FROM workshops WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            w = mycursor.fetchall()
            if w!=None:
               work=[]
               for i in w:
                  obj=Workshop()
                  obj.wtitle=i[0]
                  obj.duration=i[1]
                  obj.date=i[2]
                  obj.wcn=i[3]
                  work.append(obj)
            else:
                w_details=None
                work=None

#gpa        SELECT sem, COUNT(*) AS count, SUM(credits * 10) AS total_credits FROM tsheets WHERE rollno = '19281A0562' AND credits > 0 GROUP BY sem;
            
                  
            
            query  = "SELECT rollno, sem, ROUND(SUM(gradepoint * credits) / SUM(credits), 2) AS sgpa FROM tsheets WHERE rollno = '"+rollno+"' and credits>0 GROUP BY rollno, sem;"
           
           
            mycursor.execute(query)
            result=mycursor.fetchall()
            if result!=None:


                for i in result:
                     q  = "SELECT SUM(gradepoints*credits)  FROM tsheets WHERE rollno ='"+rollno+"' AND sem='i[0]' GROUP BY sem"
           



    
            


            


           
            
            return render(request,"registration_details_f.html",{'place_details':place_details,'pla':pla,'w_details':w_details,'work':work,'project_details':project_details,'pr':pr,'paper_details':paper_details,'pps':pps,'intern_details':intern_details,'interns':interns,'user_info_college':user_info_college,'user_info_p_det':user_info_p_det,'user_info_ssc':user_info_ssc,'certif_details':certif_details,'certif':certif,'achieve_details':achieve_details,'achieves':achieves,'email_f':email})
        
        
        
    
    
            
            
          
    else:        

        return render(request,"signin.html")

def performance_f(request,rollno):
    if "email_f" in request.session:
        email=request.session.get("email_f")
        if request.method=='POST':
            t=request.POST.get('type',None)
            conn = mysql.connector.connect(host="localhost", user="root", password="",database="studentdb")
            mycursor = conn.cursor()
            query  = "SELECT fname,lname FROM students WHERE rollno = '"+rollno+"'"
            mycursor.execute(query)
            result1=mycursor.fetchone()
            if result1!=None:
                  name=result1[0]+" "+result1[1]
            else:
                return  render(request,'performance_f.html',{'email_f':email})

            query  = "SELECT  sem, CASE WHEN SUM(CASE WHEN grade = 'F' OR gradepoint = 0 THEN 1 ELSE 0 END) > 0 THEN 1 ELSE ROUND(SUM(gradepoint * credits) / SUM(credits), 2) END AS sgpa, CASE WHEN SUM(CASE WHEN grade = 'F' OR gradepoint = 0 THEN 1 ELSE 0 END) > 0 THEN 1 ELSE ROUND(AVG(SUM(gradepoint * credits) / SUM(credits)) OVER (PARTITION BY rollno ORDER BY sem), 2) END AS cgpa FROM tsheets WHERE rollno = %s GROUP BY rollno, sem;"
            mycursor.execute(query, (rollno))
            result=mycursor.fetchall()

            
            query1  = "SELECT max(semester) from students WHERE rollno = '"+rollno+"' "
            
            mycursor.execute(query)
            result1=mycursor.fetchone()
            if result1!=None:
                k=result1[0]
            
                query2 = "SELECT attendance from students WHERE rollno = '"+rollno+"' and semester='"+str(k)+"'"
            
                mycursor.execute(query2)
                result2=mycursor.fetchone()
                y=result2[0]
            query3 = "SELECT t1.subname as subname, t1.marks AS mid1, COALESCE(t2.marks, 0) AS mid2, CASE WHEN t2.marks IS NULL THEN 0 ELSE ROUND((t1.marks + t2.marks)/2) END AS average FROM mids t1 LEFT JOIN mids t2 ON t1.rollno = t2.rollno AND t1.subname = t2.subname AND t2.mid_no = '2' WHERE t1.rollno =%s AND t1.sem = %s AND t1.mid_no = '1';"
            mycursor.execute(query3, (rollno, result1[0]))
            result3 = mycursor.fetchall()
            
            if result!=None and result3!=None:

                
                sem=[]
                for x in result:
                         obj=Result_s()
                         obj.seme=x[0]
                         obj.sgpa=x[1]
                         obj.cgpa=x[2]
                        
                         sem.append(obj)
                mid=[]
                for x in result1:
                        obj=Result_m()
                        obj.subname=x[0]
                        obj.mid1=x[1]
                        obj.mid2=x[2]
                        obj.average=x[3]
                        mid.append(obj)
                if t=='table':
                    if len(sem)<=0:
                        sem=None
                    if len(mid)<=0:
                        mid=None
                    if y==0:
                        y=None


                    return  render(request,'tables_f.html',{'email_f':email,'name':name,'sem':sem,'mid':mid,'y':y})
                elif t=='graph':
                    seme = [result.seme for result in sem]
                    sgpa = [result.sgpa for result in sem]
                    
                    colors = []
                    for value in sgpa:
                        if value == 1.00:
                           colors.append('red')
                        elif value > 9.00:
                            colors.append('green')
                        else:
                            colors.append('blue')


    # Map each semester to a color from the color map

    # Barplot for sgpa
                    
    
                    if len(seme)>0 and len(sgpa)>0:
                        fig, ax = plt.subplots(figsize=(8, 6))
                   
                        x=ax.bar(seme, sgpa ,color=colors)

                        ax.set_xlabel('Semester')
                        ax.set_ylabel('Semester GPA')
                        ax.set_title('Semester Results')
                        ax.set_ylim(0, 10)
                        for rect in x:
                            height = rect.get_height()
                            if height == 1:
                                plt.text(rect.get_x() + rect.get_width() / 2.0, height, '0', ha='center', va='bottom')
                            else:
                                plt.text(rect.get_x() + rect.get_width() / 2.0, height, f'{height:.2f}', ha='center', va='bottom')
                    
                        red_patch = mpatches.Patch(color='red', label='Backlogs')
                        blue_patch = mpatches.Patch(color='blue', label='No Backlogs')
                        green_patch= mpatches.Patch(color='green', label='Above 9.0 sgpa')
                    
                        ax.legend(handles=[red_patch, blue_patch,green_patch], bbox_to_anchor=(1.05, 1), loc='upper left')
                        graph_file1 = 'semester_results_1.png'
                        fig.savefig('C:/external/counselling/static/image/'+ graph_file1,bbox_inches='tight')
                    else:
                        graph_file1 = None
                        #fig.savefig('C:/external/counselling/static/image/'+ graph_file1,bbox_inches='tight')
    
    # Convert the graph to an HTML string
    # line plot for cgpa
                
                    cgpa = [result.cgpa for result in sem]
                    colors = []
                    for value in cgpa:
                        if value <= 1.00:
                           colors.append('red')
                        else:
                           colors.append('#B2BEB5')
                  
    
                    if len(cgpa)>0:
                        
                        fig2, ax2 = plt.subplots()
                        ax2.plot(seme, cgpa, marker='o', markersize=5, color='blue', label='No Backlogs')
                        ax2.plot(seme, cgpa, marker='o', markersize=5, color='red', label='Have Backlogs')
                        ax2.plot(seme, cgpa, marker='o', markersize=5, color='green', label='Above 9.0 cgpa')
                        for i in range(len(seme)-1):
                            if cgpa[i] == 1:
                                ax2.plot([seme[i], seme[i+1]], [cgpa[i], cgpa[i+1]], color='black')
                                ax2.plot(seme[i], cgpa[i], marker='o', markersize=5, color='red')
                                ax2.annotate('0', xy=(seme[i], cgpa[i]), xytext=(seme[i]+0.1, cgpa[i]+0.1), fontsize=10,ha='left', va='bottom')
                            elif cgpa[i]<9:
    
                                ax2.plot([seme[i], seme[i+1]], [cgpa[i], cgpa[i+1]], color='black')
                                ax2.plot(seme[i], cgpa[i], marker='o', markersize=5, color='blue')
                                ax2.annotate(f'{cgpa[i]:.2f}', xy=(seme[i], cgpa[i]), xytext=(seme[i], cgpa[i]), fontsize=10,ha='left', va='bottom')
                            else:
                                ax2.plot([seme[i], seme[i+1]], [cgpa[i], cgpa[i+1]], color='black')
                                ax2.plot(seme[i], cgpa[i], marker='o', markersize=5, color='green')
                                ax2.annotate(f'{cgpa[i]:.2f}', xy=(seme[i], cgpa[i]), xytext=(seme[i], cgpa[i]), fontsize=10,ha='left', va='bottom')
                    
                        if cgpa[-1] == 1:
                           ax2.plot(seme[-1], cgpa[-1], marker='o', markersize=5, color='red')
                           ax2.annotate(0, xy=(seme[-1], cgpa[-1]), xytext=(seme[-1], cgpa[-1]), fontsize=10,ha='left', va='bottom')
                        elif cgpa[-1]<9:
                            ax2.plot(seme[-1], cgpa[-1], marker='o', markersize=5, color='blue')
                            ax2.annotate(f'{cgpa[-1]:.2f}', xy=(seme[-1], cgpa[-1]), xytext=(seme[-1], cgpa[-1]), fontsize=10,ha='left', va='bottom')
                        else:
                            ax2.plot(seme[-1], cgpa[-1], marker='o', markersize=5, color='green')
                            ax2.annotate(f'{cgpa[-1]:.2f}', xy=(seme[-1], cgpa[-1]), xytext=(seme[-1], cgpa[-1]), fontsize=10,ha='left', va='bottom')
                        ax2.set_title('CGPA based results')
                        ax2.legend(loc='center left', bbox_to_anchor=(1, 0.5))

                        graph_file2 = 'semester_results_2.png'
                        fig2.savefig('C:/external/counselling/static/image/'+ graph_file2,bbox_inches='tight')
                    else:
                        graph_file2=None


        #midmarks
                    subname = [x.subname for x in mid]
                    mid1 = [x.mid1 for x in mid]
                    mid2 = [x.mid2 for x in mid]
                    avg = [x.average for x in mid]   
                    if len(mid1)>0 and len(subname)>0 and len(mid2)>0 and len(avg)>0:
                        plt.figure(figsize=(10, 6))
                        plt.style.use('ggplot')
                        bar_width = 0.35
                    #plt.xticks([r + bar_width / 2 for r in range(len(subname))], subname)
                        r1 = [x * 3 for x in range(len(subname))]
                        r2 = [x * 3 + 1 for x in range(len(subname))]
                        r3 = [x * 3 + 2 for x in range(len(subname))]
                    
                        bar_spacing = 0.05

# set x-tick locations for each bar group
                    

                        for i in range(len(mid)):
                            num_ticks = 10
                            xtick_locations = np.arange(num_ticks) * bar_width + r2[i] - bar_width / 2
                            #if i % 3 == 0:
                                  #plt.xticks([r + bar_width for r in range(i, i+3)], subname[i:i+3])
                            if avg[i] <14:
                                plt.bar(r1[i], mid1[i], color='blue', width=bar_width, edgecolor='black', label='Mid1')
                                plt.bar(r2[i], mid2[i], color='orange', width=bar_width, edgecolor='black', label='Mid2')
                                plt.bar(r3[i], avg[i], color='red', width=bar_width, edgecolor='black', label='average')
                            else:
                                 plt.bar(r1[i], mid1[i], color='blue', width=bar_width, edgecolor='black', label='Mid1')
                                 plt.bar(r2[i], mid2[i], color='orange', width=bar_width, edgecolor='black', label='Mid2')
                                 plt.bar(r3[i], avg[i], color='green', width=bar_width, edgecolor='black', label='average')
                            plt.text(r1[i], mid1[i], str(mid1[i]), ha='center', va='bottom', fontsize=10)
                            plt.text(r2[i], mid2[i], str(mid2[i]), ha='center', va='bottom', fontsize=10)
                            plt.text(r3[i], avg[i], str(avg[i]), ha='center', va='bottom', fontsize=10)
                        plt.xlabel('Subjects')
                        plt.ylabel('Marks')
                        plt.title('Mid-term Marks')
                        plt.xticks([r*3 + bar_width+1 for r in range(len(subname))], subname)


                    

                        for i in range(0, len(subname)*3, 3):
                                plt.axvline(x=i-0.5, color='black', linewidth=3)
                        red_patch = mpatches.Patch(color='red', label='Fail')
                        blue_patch = mpatches.Patch(color='blue', label='Mid1')
                        orange_patch= mpatches.Patch(color='orange', label='Mid2')
                        green_patch= mpatches.Patch(color='green', label='good average')
                    
                        plt.legend(handles=[red_patch, blue_patch,orange_patch,green_patch], bbox_to_anchor=(1.05, 1), loc='upper left')
                        graph_file3 = 'mid_marks.png'
                        plt.savefig('C:/external/counselling/static/image/'+ graph_file3,bbox_inches='tight')
                    else:
                        graph_file3=None
         #ATTENDANCE
                    
                    percentage_attendance = y / 100.0

# calculate the percentage of absences
                    percentage_absences = 1 - percentage_attendance

# create a list of attendance and absences percentages
                    attendance_percentages = [percentage_attendance, percentage_absences]

# create a list of labels for the pie chart
                    labels = ['present', 'Absence']

# set the colors for the pie chart
                    if y>75:
                          colors = ['green', 'wheat']
                    elif y<75 and y>65:
                        colors = ['yellow', 'wheat']
                    else:
                        colors = ['red', 'wheat']


# create the pie chart
                    fig3, ax3 = plt.subplots()
                    ax3.pie(attendance_percentages, colors=colors, labels=labels, autopct='%1.1f%%', startangle=90)
                    red_patch = mpatches.Patch(color='red', label='<65%')
                    blue_patch = mpatches.Patch(color='yellow', label='<75% & >65%')
                    green_patch= mpatches.Patch(color='green', label='>75%')
                    
                    plt.legend(handles=[red_patch, blue_patch,green_patch], bbox_to_anchor=(1.05, 1), loc='upper left')
                    graph_file4 = 'attend.png'
                    f='Attendance of semester:'+" "+str(k)

                    ax3.set_title(f)
                    fig3.savefig('C:/external/counselling/static/image/'+ graph_file4,bbox_inches='tight')
                    if y<=0:
                        graph_file4=None


                    
    
                
                    return render(request, 'graphs_f.html', {'graph_file4':graph_file4,'graph_file3':graph_file3,'graph_file1': graph_file1,'graph_file2':graph_file2,'name':name,'email_f':email})
                else:
                     return  render(request,'performance_f.html',{'email_f':email})



            else:
                return  render(request,'performance_f.html',{'email_f':email})
    





        else:
            return  render(request,'performance_f.html',{'email_f':email})
    else:
        return  render(request,'signin.html')



def tables_f(request):
    return render(request,"tables_f.html")
def graphs_f(request):
    return render(request,"graphs_f.html")


