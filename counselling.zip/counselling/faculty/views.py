from django.shortcuts import render, redirect
from django.http import HttpResponse
import mysql.connector
#from django.db.models import Sum, F, FloatField
from django.http import JsonResponse
from datetime import datetime
from django.forms.models import model_to_dict
from django.contrib import messages
from django.urls import reverse
from django.core.files.storage import FileSystemStorage
#from .forms import MyForm
import smtplib
import matplotlib.patches as mpatches
import numpy as np
import matplotlib.pyplot as plt
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from .models import *
# Create your views here.
from django.http import HttpResponse
import mysql.connector
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.csrf import ensure_csrf_cookie
@ensure_csrf_cookie
@csrf_exempt
def index(request):
    return render(request,"index.html")
def message(request):
    return render(request,"message.html")
def student_details_a_table(request):
    return render(request,"student_details_a_table.html")
def registration_details(request,rollno):
    if "email_a" in request.session:
        email = request.session.get("email_a")
        #mycursor.execute(" from faculty where email='{email}'")
        if request.method=='POST':
            return render(request,"registration_details.html")

        else:
            conn=mysql.connector.connect(host="localhost", user="root", password="", database= "studentdb")
            mycursor=conn.cursor()
            #SSC AND COLLEGE DETAILS
            column_details=['schoolname','board','passoutyear','percentage']
            education_type = 'SSC'
            query = "SELECT schoolname, board, passoutyear, percentage FROM education WHERE rollno = %s AND education = %s"
            params = (rollno, education_type)
            mycursor.execute(query, params)
            ssc = mycursor.fetchone()
            if ssc!=None:
                  user_info_ssc = [(column_details[i], ssc[i]) for i in range(len(ssc))]
            else:
                user_info_ssc=None

# Retrieve college details
            education_type = 'INTER/DIPLOMA'
            query = "SELECT schoolname, board, passoutyear, percentage FROM education WHERE rollno = %s AND education = %s"
            params = (rollno, education_type)
            mycursor.execute(query, params)
            college = mycursor.fetchone()
            if college!=None:
                   user_info_college = [(column_details[i], college[i]) for i in range(len(college))]
            else:
                user_info_college=None
  # PERSONAL DETAILS
            column_details=['rollno', 'branch', 'student-name', 'gender', 'student-aadhaar', 'student-mobile', 'student-email', 'date-of-birth', 'blood-group', 'address_temporary', 'address_permanent', 'caste', 'subcaste', 'religion', 'father-name', 'mother-name', 'father-occupation', 'mother-occupation', 'father-designation', 'mother-designation', 'father-income', 'mother-income', 'father-mobile', 'mother-mobile', 'father-email', 'mother-email', 'father-aadhar', 'mother-aadhar', 'aggregrate', 'Total-backlogs']
            
            query = f"SELECT rollno,branch, sname, gender, saadhaar, smobile, semail, dob, bgrp, add_comm, add_perm, caste, subcaste, religion, father, mother, focu, mocu, fdes, mdes, finc, minc, fmob, mmob, femail, memail, faad, maad, agg, tbacklogs FROM student WHERE rollno = '{rollno}' "
            
            mycursor.execute(query)
            p_det = mycursor.fetchone()
            if p_det!=None:
                 user_info_p_det = [(column_details[i], p_det[i]) for i in range(len(p_det))]
            else:
                user_info_p_det=None

#CERTIFICATIONS
            certif_details=['Certification_Name','Issued-By','Date-of-Issue']
            
            query = "SELECT skill,issue,date FROM certification WHERE rollno = %s "
            params=(rollno,)
           
            mycursor.execute(query,params)
            certi = mycursor.fetchall()
            if certi!=None:
               certif=[]
               for i in certi:
                  obj=Certif()
                  obj.skill=i[0]
                  obj.issue=i[1]
                  obj.date=i[2]
                  certif.append(obj)
            else:
                certif_details=None
                certif=None
# ACHIEVEMENTS
            achieve_details=['Achievement_Name','Date-of-Issue']
            
            query = "SELECT achname,date FROM achieve WHERE rollno = %s "
            params=(rollno,)
           
            mycursor.execute(query,params)
            achieve = mycursor.fetchall()
            if achieve!=None:
               achieves=[]
               for i in achieve:
                  obj=Achieve()
                  obj.achname=i[0]
                  #obj.issue=i[1]
                  obj.date=i[1]
                  achieves.append(obj)
            else:
                achieve_details=None
                achieves=None
#INTERNSHIPS
            intern_details=['Title','Company-Name','Date-of-start','End-Date']
            
            query = "SELECT title,cn,date,end FROM internship WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            intern = mycursor.fetchall()
            if intern!=None:
               interns=[]
               for i in intern:
                  obj=Internship()
                  obj.title=i[0]
                  obj.cn=i[1]
                  obj.date=i[2]
                  obj.end=i[3]
                  interns.append(obj)
            else:
                intern_details=None
                interns=None

#PAPER PRESENTATIONS
            paper_details=['Paper-Title','Paper-Type','Guide','Date']
            
            query = "SELECT pptitle,ptype,guide,date FROM paperpresentations WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            pp = mycursor.fetchall()
            if pp!=None:
               pps=[]
               for i in pp:
                  obj=PaperP()
                  obj.pptitle=i[0]
                  obj.ptype=i[1]
                  obj.guide=i[2]
                  obj.date=i[3]
                  pps.append(obj)
            else:
                paper_details=None
                pps=None


#PROJECTS
            project_details=['Project-Title','Guide','Project Description','Date']
            
            query = "SELECT ptitle,guide,pdescription,date FROM projects WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            p = mycursor.fetchall()
            if p!=None:
               pr=[]
               for i in p:
                  obj=Project()
                  obj.ptitle=i[0]
                  obj.guide=i[1]
                  obj.pdescription=i[2]
                  obj.date=i[3]
                  pr.append(obj)
            else:
                project_details=None
                pr=None

#PLACEMENTS
            place_details=['Company-Name','Year','Package']
            
            query = "SELECT cname,year,pack FROM place WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            p = mycursor.fetchall()
            if p!=None:
               pla=[]
               for i in p:
                  obj=Placement()
                  obj.cname=i[0]
                  obj.year=i[1]
                  obj.pack=i[2]
                  #obj.date=i[3]
                  pla.append(obj)
            else:
                place_details=None
                pla=None


#workshops  
            w_details=['Workshop-Title','Duration-in-Days','Date','Conducted-By']
            
            query = "SELECT wtitle,duration,date,wcn FROM workshops WHERE rollno = %s"
            params=(rollno,)
           
            mycursor.execute(query,params)
           
            #mycursor.execute(query)
            w = mycursor.fetchall()
            if w!=None:
               work=[]
               for i in w:
                  obj=Workshop()
                  obj.wtitle=i[0]
                  obj.duration=i[1]
                  obj.date=i[2]
                  obj.wcn=i[3]
                  work.append(obj)
            else:
                w_details=None
                work=None

#gpa        SELECT sem, COUNT(*) AS count, SUM(credits * 10) AS total_credits FROM tsheets WHERE rollno = '19281A0562' AND credits > 0 GROUP BY sem;
            
                  
            
            query  = "SELECT rollno, sem, ROUND(SUM(gradepoint * credits) / SUM(credits), 2) AS sgpa FROM tsheets WHERE rollno = '"+rollno+"' and credits>0 GROUP BY rollno, sem;"
           
           
            mycursor.execute(query)
            result=mycursor.fetchall()
            if result!=None:


                for i in result:
                     q  = "SELECT SUM(gradepoints*credits)  FROM tsheets WHERE rollno ='"+rollno+"' AND sem='i[0]' GROUP BY sem"
           



    # Loop over all semesters and calculate the GPA for each one
            #semester_gpas = []
            #for semester in result:

        # Retrieve all records for the given rollno and semester

                

        # Calculate the total credit points and grade points for the semester
                #total_credit_points = records.aggregate(total_credit_points=Sum('credits'))['total_credit_points']
                #total_grade_points = records.annotate(grade_points=F('gradepoint') * F('credits')).aggregate(total_grade_points=Sum('grade_points', output_field=FloatField()))['total_grade_points']

        # Calculate the semester GPA
               # semester_gpa = total_grade_points / total_credit_points

        # Add the semester GPA to the list
               # semester_gpas.append(semester_gpa)
            


            


           
            
            return render(request,"registration_details.html",{'place_details':place_details,'pla':pla,'w_details':w_details,'work':work,'project_details':project_details,'pr':pr,'paper_details':paper_details,'pps':pps,'intern_details':intern_details,'interns':interns,'user_info_college':user_info_college,'user_info_p_det':user_info_p_det,'user_info_ssc':user_info_ssc,'certif_details':certif_details,'certif':certif,'achieve_details':achieve_details,'achieves':achieves,'email_a':email})
        
        
        
    
    
            
            
          
    else:        

        return render(request,"signin.html")





           


def student_details_a(request):
    
    if "email_a" in request.session:
        email = request.session.get("email_a")
        #mycursor.execute(" from faculty where email='{email}'")
        if request.method=='POST':
            
                branch1=request.POST.get('branch1',None)
                year1=request.POST.get('year1',None)
                sem1=request.POST.get('sem1', None)
                section1=request.POST.get('section1', None)
                conn=mysql.connector.connect(host="localhost", user="root", password="", database="studentdb")
                mycursor=conn.cursor()

                if branch1!="Select Branch" and year1!= "Select Year"and sem1!="Select Semester" and section1!="Select Section":
                    
                    mycursor.execute("select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section,attendance from students where branch='"+branch1+"' and year='"+year1+"' and semester='"+sem1+"' and section='"+section1+"' ORDER BY rollno")
                    result=mycursor.fetchall()
                    if result!=None:
                        
                        details = []
                        for row in result:
                                obj = Students()         
                                obj.rollno = row[0]
                                obj.fname = row[1]
                                obj.lname=row[2]
                                obj.email = row[3]
                                obj.branch = row[4]
                                obj.year = row[5]
                                obj.semester = row[6]
                                obj.studmob = row[7]
                                obj.fmob = row[8]
                                obj.section = row[9]
                                obj.attendance = row[10]
                                # obj.gpa = row[10]
                                
                                details.append(obj)
                
                         
                            #column_names = [column for column in column_details]
    
    # Create a list of tuples with column names and user details
                           
                        return render(request, 'student_details_a_table.html', {'details':details,'email_a':email})
                    else:
                        return render(request, 'student_details_a.html', {'email_a':email})
                elif branch1!="Select Branch" and year1!= "Select Year"and sem1!="Select Semester" :
                    
                    mycursor.execute("select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section,attendance  from students where branch='"+branch1+"' and year='"+year1+"' and semester='"+sem1+"' ORDER BY rollno")
                    result=mycursor.fetchall()
                    if result!=None:
                        
                        details = []
                        for row in result:
                                obj = Students()         
                                obj.rollno = row[0]
                                obj.fname = row[1]
                                obj.lname=row[2]
                                obj.email = row[3]
                                obj.branch = row[4]
                                obj.year = row[5]
                                obj.semester = row[6]
                                obj.studmob = row[7]
                                obj.fmob = row[8]
                                obj.section = row[9]
                                #obj.gender = row[10]
                                obj.attendance = row[10]
                                
                                details.append(obj)
                
                         
                            #column_names = [column for column in column_details]
    
    # Create a list of tuples with column names and user details
                           
                        return render(request, 'student_details_a_table.html', {'details':details,'email_a':email})
                    else:
                        return render(request, 'student_details_a.html', {'email_a':email})
                        
                elif branch1!="Select Branch":
                    
                    mycursor.execute("select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section,attendance from students where branch='"+branch1+"' ORDER BY rollno")
                    result=mycursor.fetchall()
                    if result!=None:
                        
                        details = []
                        for row in result:
                                obj = Students()         
                                obj.rollno = row[0]
                                obj.fname = row[1]
                                obj.lname=row[2]
                                obj.email = row[3]
                                obj.branch = row[4]
                                obj.year = row[5]
                                obj.semester = row[6]
                                obj.studmob = row[7]
                                obj.fmob = row[8]
                                obj.section = row[9]
                                #obj.gender = row[10]
                                obj.attendance = row[10]
                                
                                details.append(obj)
                       
                        
                            
                        return render(request, 'student_details_a_table.html', {'details':details,'email_a':email})
                    else:
                        return render(request, 'student_details_a.html', {'email_a':email})





                elif branch1!="Select Branch"and year1!= "Select Year":
                    
                    mycursor.execute("select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section,attendance from students where branch='"+branch1+"' and year='"+year1+"' ORDER BY rollno")
                    result=mycursor.fetchall()
                    if result!=None:
                        
                            #obj=Faculty()
                           
                        details = []
                        for row in result:
                                obj = Students()         
                                obj.rollno = row[0]
                                obj.fname = row[1]
                                obj.lname=row[2]
                                obj.email = row[3]
                                obj.branch = row[4]
                                obj.year = row[5]
                                obj.semester = row[6]
                                obj.studmob = row[7]
                                obj.fmob = row[8]
                                obj.section = row[9]
                                #obj.gender = row[10]
                                obj.attendance = row[10]
                                
                                details.append(obj)
                        return render(request, 'student_details_a_table.html', {'details':details,'email_a':email})
                    else:
                            return render(request, 'student_details_a.html', {'email_a':email})


                elif branch1!="Select Branch" and sem1!="Select Semester":
                    
                    mycursor.execute("select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section,attendance from students where branch='"+branch1+"' and semester='"+sem1+"' ORDER BY rollno")
                    result=mycursor.fetchall()
                    if result!=None:
                        
                            #obj=Faculty()
                            
                        details = []
                        for row in result:
                                obj = Students()         
                                obj.rollno = row[0]
                                obj.fname = row[1]
                                obj.lname=row[2]
                                obj.email = row[3]
                                obj.branch = row[4]
                                obj.year = row[5]
                                obj.semester = row[6]
                                obj.studmob = row[7]
                                obj.fmob = row[8]
                                obj.section = row[9]
                                #obj.gender = row[10]
                                obj.attendance = row[10]
                                
                                details.append(obj)
                
                        return render(request, 'student_details_a_table.html', {'details':details,'email_a':email})
                    else:
                        return render(request, 'student_details_a.html', {'status':'Cannot Show the details','email_a':email})

                elif year1!="Select Year" and sem1!="Select Semester":
                    
                    mycursor.execute("select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section,attendance from students where year='"+year1+"' and semester='"+sem1+"' ORDER BY rollno")
                    result=mycursor.fetchall()
                    if result!=None:
                        
                            #obj=Faculty()
                            
                        details = []
                        for row in result:
                                obj = Students()         
                                obj.rollno = row[0]
                                obj.fname = row[1]
                                obj.lname=row[2]
                                obj.email = row[3]
                                obj.branch = row[4]
                                obj.year = row[5]
                                obj.semester = row[6]
                                obj.studmob = row[7]
                                obj.fmob = row[8]
                                obj.section = row[9]
                                #obj.gender = row[10]
                                obj.attendance = row[10]
                                
                                details.append(obj)
                
                        return render(request, 'student_details_a_table.html', {'details':details,'email_a':email})
                else:
                        return render(request, 'student_details_a.html', {'status':'Cannot Show the details','email_a':email})
            
                








        else:    
            conn=mysql.connector.connect(host="localhost", user="root", password="", database= "counsellingdb")
            mycursor=conn.cursor()
            mycursor.execute("select * from branches")
            result=mycursor.fetchall()
            branches=[]  
            for x in result:
                obj=Branch()
                obj.bid=x[0]
                obj.branch=x[1]
                branches.append(obj)

           
            mycursor.execute("select * from years")
            result=mycursor.fetchall()
            years=[]  
            for x in result:
                obj=Years()
                obj.year=x[0]
                years.append(obj)
            mycursor.execute("select * from semester")
            result=mycursor.fetchall()
            sem=[]  
            for x in result:
                 obj=Semester()
                 obj.sem=x[0]
                 sem.append(obj)
            return  render(request,'student_details_a.html',{'branches':branches,'years':years,'sem':sem,'email_a':email})
        
        
        
    
    
            
            
          
    else:        

        return render(request,"signin.html")


#-------------------------------------------------------------------------------
#----SIGN_UP--------


def signup(request):
    if request.method=='POST':
        #connect to db
        conn=mysql.connector.connect(host="localhost", user="root", password="",database="counsellingdb")
        mycursor=conn.cursor()
        #get current year
        c = datetime.now().year
        currentYear=c%100
        #form elements retrieveal
        gender=request.POST['selectedgender']
        fname=request.POST['fname']
        lname=request.POST['lname']
        email=request.POST['email']
        pwd=request.POST['pwd']
        cpwd=request.POST['cpwd']
        branch=request.POST['branch']
        role=request.POST['role']
        phno=request.POST['phno']
        mycursor.execute("select bid from branches where branch='"+branch+"'")
        result=mycursor.fetchone()
        obj=Branch()
        branchid=result[0]
        mycursor.execute("select roleid from roles where rolename='"+role+"'")
        result=mycursor.fetchone()
        obj=Roles()
        roleid=result[0]
        
        mycursor.execute("SELECT MAX(empid) FROM faculty WHERE branch = %s", (branchid,))
        result = mycursor.fetchone()

# extract max empid and generate new empid
        if result[0] is not None:
          max_empid = result[0]
          incremental_digits = int(max_empid%100) + 1 if max_empid%100 != '99' else 0
        else:
          incremental_digits = 1

        empid = f"{str(currentYear)[-2:]}{branchid}{incremental_digits:02d}"
        mycursor.execute("select email from faculty where email='"+email+"'")
        result=mycursor.fetchone()
        if result==None:
            mycursor.execute("insert into faculty(empid,firstname,lastname,email, password, phonenumber, branch, gender,roleid) values('"+empid+"','"+fname+"','"+lname+"','"+email+"','"+pwd+"','"+phno+"','"+str(branchid)+"','"+gender+"','"+str(roleid)+"')")
            conn.commit()
            return redirect('signin')
        else:
            return render(request,'signup.html',{'status':"You have already registered!"})
    else:
        conn=mysql.connector.connect(host="localhost", user="root", password="",database="counsellingdb")
        mycursor=conn.cursor()
        mycursor.execute("select * from branches")

        result=mycursor.fetchall()
        branches=[]
        
        for x in result:
            obj=Branch()
            obj.bid=x[0]
            obj.branch=x[1]
            branches.append(obj)
        mycursor.execute("select * from roles")
        roles=[]
        result=mycursor.fetchall()
        for x in result:
            obj=Roles()
            obj.roleid=x[0]
            obj.rolename=x[1]
            roles.append(obj)
        
        return render(request,'signup.html',{'branches':branches,"roles":roles})
         
        #return render(request,"signin.html")
    #return render(request,"signup.html")

#-------------------------------------------------------------------------------
#----FORGOT--------



def forgot(request):
    if request.method=="POST":
        conn=mysql.connector.connect(host="localhost", user="root", password="",database="counsellingdb")
        mycursor=conn.cursor()
        #retrieve post details
        #name=request.POST['name']
        email=request.POST['email']
        role=request.POST['roles']
        if role=='faculty':
            mycursor.execute("select email,password from faculty where email='"+email+"'")
            result=mycursor.fetchone()
            
            if result==None:
                # create the form and render the template
                
                return render(request, 'signup.html', {'status':'You are not a valid user. Please sign up! '})
            else:
         
                pwd=str(result[1])
                smtp_server = 'smtp.gmail.com'
                smtp_port = 587
                smtp_username = 'priyadharshinithummeti@gmail.com'
# for App Password enable 2-step verification then u can create app password
                smtp_password = 'qrux yjxy oipm zqof'

# Email content
                subject = 'Password recovery'
                body = 'This is a Password recovery email sent from kits.'+'Your password as per registration is: '+ pwd
                sender_email = 'priyadharshinithummeti@gmail.com'
                receiver_email = email

# Create a message
                message = MIMEMultipart()
                message['From'] = sender_email
                message['To'] = receiver_email
                message['Subject'] = subject
                message.attach(MIMEText(body, 'plain'))

    # Connect to SMTP server and send the email
                with smtplib.SMTP(smtp_server, smtp_port) as server:
                      server.starttls()
                      server.login(smtp_username, smtp_password)
                      server.sendmail(sender_email, receiver_email, message.as_string())
            
                return render(request, 'signin.html', {'status': 'Password sent to given mail ID'})
        else:
            mycursor.execute("select email,password from students where email='"+email+"'")
            result=mycursor.fetchone()
            
            if result==None:
                # create the form and render the template
                
                return render(request, 'signup.html', {'status':'You are not a valid user. Please sign up! '})
            else:
         
                pwd=str(result[1])
                smtp_server = 'smtp.gmail.com'
                smtp_port = 587
                smtp_username = 'priyadharshinithummeti@gmail.com'
# for App Password enable 2-step verification then u can create app password
                smtp_password = 'qrux yjxy oipm zqof'

# Email content
                subject = 'Password recovery'
                body = 'This is a Password recovery email sent from kits.'+'Your password as per registration is: '+ pwd
                sender_email = 'priyadharshinithummeti@gmail.com'
                receiver_email = email

# Create a message
                message = MIMEMultipart()
                message['From'] = sender_email
                message['To'] = receiver_email
                message['Subject'] = subject
                message.attach(MIMEText(body, 'plain'))

    # Connect to SMTP server and send the email
                with smtplib.SMTP(smtp_server, smtp_port) as server:
                      server.starttls()
                      server.login(smtp_username, smtp_password)
                      server.sendmail(sender_email, receiver_email, message.as_string())
            
                return render(request, 'signin.html', {'status': 'Password sent to given mail ID'})

        
    else:
        return render(request, 'forgot.html')
                # display an error message if the email is not in the database
                
    

                
            

        

    
def tables(request):
    return render(request,"tables.html")




#-------------------------------------------------------------------------------
#----SIGN_IN--------

def signin(request):
    if request.method=='POST':
        conn=mysql.connector.connect(host="localhost", user="root", password="",database="counsellingdb")
        mycursor=conn.cursor()
        #retrieve post details
        #name=request.POST['name']
        email=request.POST['email']
        pwd=request.POST['pwd']
       # cpwd=request.POST['confirm_password']
        role=request.POST['roles']
        if role=="faculty":
            mycursor.execute ("select email,password,roleid,firstname,lastname from faculty where email='"+email+"' ")
            result=mycursor.fetchone()
            obj=Faculty()
            
            if result==None:
                return redirect('signup')
            elif result[1]!=pwd:
                return render(request,'signin.html',{'status':'Please check your password!'})
            elif result[2]=='1' or result[2]=='2':
                #name=result[3]+" "+result[4]
                request.session['email_a'] = email
                return redirect('dashboard_admin')
            elif result[2]=='3':
                #name=result[3]+" "+result[4]
                request.session['email_f'] = email
                return redirect('dashboard_faculty')

            else: 
                #name=result[3]+" "+result[4]
                
                return redirect('signup')
        elif role=='student':
            conn=mysql.connector.connect(host="localhost", user="root", password="",database="studentdb")
            mycursor=conn.cursor()
            mycursor.execute ("select rollno,password from studentdetails where rollno='"+email+"' ")
            result=mycursor.fetchone()
            obj=Student()
            
            if result==None:
                return render(request,'signin.html',{'status':'You are not a valid student!'})
            elif result[1]!=pwd:
                return render(request,'signin.html',{'status':'Please check your password!'})
            else:
                
                request.session['rollno_s'] = email
                return redirect('dashboard_student')

    else:
      
        return render(request,"signin.html") 



#-----------------------------------------------------------
#---------DASHBOARD_ADMIN-------------------
def dashboard_hod(request):
    return render(request,"dashboard_hod.html")


def dashboard_admin(request):

    conn = mysql.connector.connect(host="localhost",
            user="root",
            password="",
            database="counsellingdb")
    mycursor=conn.cursor()
    if "email_a" in request.session:
        email = request.session.get("email_a")
        mycursor.execute ("select * from faculty where email='"+email+"' ")
        result=mycursor.fetchone()
        mycursor.execute("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'faculty'")
        column_details = mycursor.fetchall()
        mycursor.execute(f"SELECT * FROM faculty WHERE email='{email}'")
        user_details = mycursor.fetchone()
        
        if user_details!=None:
            obj=Faculty()
            column_names = [column[0] for column in column_details]
    
    # Create a list of tuples with column names and user details
            user_info = [(column_names[i], user_details[i]) for i in range(len(column_names))]
    
    
            
            
            return render(request, 'dashboard_admin.html', {'user_info':user_info,'email_a':email})
        
    else:
        return render(request, 'signin.html')

#----EDIT_DETAILS
 

def edit_details(request):
    conn = mysql.connector.connect(host="localhost",
            user="root",
            password="",
            database="counsellingdb")
    mycursor=conn.cursor()

 #ADMIN_EDIT_DETAILS
    if "email_a" in request.session:
        if request.method=='POST':
            email_a = request.session.get("email_a")
            try:
                email_new=request.POST['email']
            except ValueError:
                return redirect('logout_a')

            pwd=request.POST['password']
            fname=request.POST['firstname']
            lname=request.POST['lastname']
            if email_new!=email_a:
                
                result=mycursor.execute ("UPDATE faculty SET email=%s, firstname=%s, lastname=%s, password=%s WHERE email=%s", [email_new, fname, lname, pwd, email_a])
                conn.commit()
                
                return redirect('logout_a')
                #else:
                    #return redirect('edit_details')
            else:
                result=mycursor.execute ("UPDATE faculty SET email=%s, firstname=%s, lastname=%s, password=%s WHERE email=%s", [email_new, fname, lname, pwd, email_a])
                conn.commit()
                if result!=None:
                    messages.success(request, 'successfully updated')
    
                    return redirect('edit_details')
                else:
                    return redirect('dashboard_admin')

        else:       
            email_a = request.session.get("email_a")
            mycursor.execute ("select * from faculty where email='"+email_a+"' ")
            result=mycursor.fetchone()
            
            column_details = ['email', 'firstname','lastname','password']
            mycursor.execute(f"SELECT email,firstname,lastname,password FROM faculty WHERE email='{email_a}'")
            user_details = mycursor.fetchone()
        
            if user_details!=None:
                 obj=Faculty()
                 column_names = [column for column in column_details]
    
    # Create a list of tuples with column names and user details
                 user_info = [(column_names[i], user_details[i]) for i in range(len(user_details))]
                 return render(request, 'edit_details.html', {'user_info':user_info,'email_a':email_a})
        
    else:
        return render(request, 'signin.html')
def performance(request,rollno):
    if "email_a" in request.session:
        email=request.session.get("email_a")
        if request.method=='POST':
            t=request.POST.get('type',None)
            conn = mysql.connector.connect(host="localhost", user="root", password="",database="studentdb")
            mycursor = conn.cursor()
            query  = "SELECT fname,lname FROM students WHERE rollno = '"+rollno+"'"
            mycursor.execute(query)
            result1=mycursor.fetchone()
            if result1!=None:
                  name=result1[0]+" "+result1[1]
            else:
                return  render(request,'performance.html',{'email_a':email})

            query  = "SELECT  sem, CASE WHEN SUM(CASE WHEN grade = 'F' OR gradepoint = 0 THEN 1 ELSE 0 END) > 0 THEN 1 ELSE ROUND(SUM(gradepoint * credits) / SUM(credits), 2) END AS sgpa, CASE WHEN SUM(CASE WHEN grade = 'F' OR gradepoint = 0 THEN 1 ELSE 0 END) > 0 THEN 1 ELSE ROUND(AVG(SUM(gradepoint * credits) / SUM(credits)) OVER (PARTITION BY rollno ORDER BY sem), 2) END AS cgpa FROM tsheets WHERE rollno = '"+rollno+"' GROUP BY rollno, sem;"
            mycursor.execute(query)
            result=mycursor.fetchall()
            query1  = "SELECT t1.subname as subname, t1.marks AS mid1, COALESCE(t2.marks, 0) AS mid2, CASE WHEN t2.marks IS NULL THEN 0 ELSE round((t1.marks + t2.marks)/2) END AS average FROM mids t1 LEFT JOIN mids t2 ON t1.rollno = t2.rollno AND t1.subname = t2.subname AND t2.mid_no = '2' WHERE t1.rollno = '"+rollno+"' AND t1.mid_no = '1';"
            
            mycursor.execute(query1)
            result1=mycursor.fetchall()
            query2  = "SELECT max(semester) from students WHERE rollno = '"+rollno+"' "
            
            mycursor.execute(query2)
            result2=mycursor.fetchone()
            if result2!=None:
                k=result2[0]
            
                query3 = "SELECT attendance from students WHERE rollno = '"+rollno+"' and semester='"+str(k)+"'"
            
                mycursor.execute(query3)
                result3=mycursor.fetchone()
                y=result3[0]
            
            if result!=None and result1!=None:

                
                sem=[]
                for x in result:
                         obj=Result_s()
                         obj.seme=x[0]
                         obj.sgpa=x[1]
                         obj.cgpa=x[2]
                        
                         sem.append(obj)
                mid=[]
                for x in result1:
                        obj=Result_m()
                        obj.subname=x[0]
                        obj.mid1=x[1]
                        obj.mid2=x[2]
                        obj.average=x[3]
                        mid.append(obj)
                if t=='table':
                    if len(sem)<=0:
                        sem=None
                    if len(mid)<=0:
                        mid=None
                    if y==0:
                        y=None


                    return  render(request,'tables.html',{'email_a':email,'name':name,'sem':sem,'mid':mid,'y':y})
                elif t=='graph':
                    seme = [result.seme for result in sem]
                    sgpa = [result.sgpa for result in sem]
                    
                    colors = []
                    for value in sgpa:
                        if value == 1.00:
                           colors.append('red')
                        elif value >= 9.00:
                            colors.append('green')
                        else:
                            colors.append('blue')


    # Map each semester to a color from the color map

    # Barplot for sgpa
                    
    
                    if len(seme)>0 and len(sgpa)>0:
                        fig, ax = plt.subplots(figsize=(8, 6))
                   
                        x=ax.bar(seme, sgpa ,color=colors)

                        ax.set_xlabel('Semester')
                        ax.set_ylabel('Semester GPA')
                        ax.set_title('Semester Results')
                        ax.set_ylim(0, 10)
                        for rect in x:
                            height = rect.get_height()
                            if height == 1:
                                plt.text(rect.get_x() + rect.get_width() / 2.0, height, '0', ha='center', va='bottom')
                            else:
                                plt.text(rect.get_x() + rect.get_width() / 2.0, height, f'{height:.2f}', ha='center', va='bottom')
                    
                        red_patch = mpatches.Patch(color='red', label='Backlogs')
                        blue_patch = mpatches.Patch(color='blue', label='No Backlogs')
                        green_patch= mpatches.Patch(color='green', label='Above 9.0 sgpa')
                    
                        ax.legend(handles=[red_patch, blue_patch,green_patch], bbox_to_anchor=(1.05, 1), loc='upper left')
                        graph_file1 = 'semester_results_1.png'
                        fig.savefig('C:/external/counselling/static/image/'+ graph_file1,bbox_inches='tight')
                    else:
                        graph_file1 = None
                        #fig.savefig('C:/external/counselling/static/image/'+ graph_file1,bbox_inches='tight')
    
    # Convert the graph to an HTML string
    # line plot for cgpa
                
                    cgpa = [result.cgpa for result in sem]
                    colors = []
                    for value in cgpa:
                        if value <= 1.00:
                           colors.append('red')
                        else:
                           colors.append('#B2BEB5')
                  
    
                    if len(cgpa)>0:
                        
                        fig2, ax2 = plt.subplots()
                        ax2.plot(seme, cgpa, marker='o', markersize=5, color='blue', label='No Backlogs')
                        ax2.plot(seme, cgpa, marker='o', markersize=5, color='red', label='Have Backlogs')
                        ax2.plot(seme, cgpa, marker='o', markersize=5, color='green', label='Above 9.0 cgpa')
                        for i in range(len(seme)-1):
                            if cgpa[i] == 1:
                                ax2.plot([seme[i], seme[i+1]], [cgpa[i], cgpa[i+1]], color='black')
                                ax2.plot(seme[i], cgpa[i], marker='o', markersize=5, color='red')
                                ax2.annotate('0', xy=(seme[i], cgpa[i]), xytext=(seme[i]+0.1, cgpa[i]+0.1), fontsize=10,ha='left', va='bottom')
                            elif cgpa[i]<9:
    
                                ax2.plot([seme[i], seme[i+1]], [cgpa[i], cgpa[i+1]], color='black')
                                ax2.plot(seme[i], cgpa[i], marker='o', markersize=5, color='blue')
                                ax2.annotate(f'{cgpa[i]:.2f}', xy=(seme[i], cgpa[i]), xytext=(seme[i], cgpa[i]), fontsize=10,ha='left', va='bottom')
                            else:
                                ax2.plot([seme[i], seme[i+1]], [cgpa[i], cgpa[i+1]], color='black')
                                ax2.plot(seme[i], cgpa[i], marker='o', markersize=5, color='green')
                                ax2.annotate(f'{cgpa[i]:.2f}', xy=(seme[i], cgpa[i]), xytext=(seme[i], cgpa[i]), fontsize=10,ha='left', va='bottom')
                    
                        if cgpa[-1] == 1:
                           ax2.plot(seme[-1], cgpa[-1], marker='o', markersize=5, color='red')
                           ax2.annotate(f'{int(cgpa[-1])}', xy=(seme[-1], cgpa[-1]), xytext=(seme[-1], cgpa[-1]), fontsize=10,ha='left', va='bottom')
                        elif cgpa[-1]<9:
                            ax2.plot(seme[-1], cgpa[-1], marker='o', markersize=5, color='blue')
                            ax2.annotate(f'{cgpa[-1]:.2f}', xy=(seme[-1], cgpa[-1]), xytext=(seme[-1], cgpa[-1]), fontsize=10,ha='left', va='bottom')
                        else:
                            ax2.plot(seme[-1], cgpa[-1], marker='o', markersize=5, color='green')
                            ax2.annotate(f'{cgpa[-1]:.2f}', xy=(seme[-1], cgpa[-1]), xytext=(seme[-1], cgpa[-1]), fontsize=10,ha='left', va='bottom')
                        ax2.set_title('CGPA based results')
                        ax2.legend(loc='center left', bbox_to_anchor=(1, 0.5))

                        graph_file2 = 'semester_results_2.png'
                        fig2.savefig('C:/external/counselling/static/image/'+ graph_file2,bbox_inches='tight')
                    else:
                        graph_file2=None


        #midmarks
                    subname = [x.subname for x in mid]
                    mid1 = [x.mid1 for x in mid]
                    mid2 = [x.mid2 for x in mid]
                    avg = [x.average for x in mid]   
                    if len(mid1)>0 and len(subname)>0 and len(mid2)>0 and len(avg)>0:
                        plt.figure(figsize=(10, 6))
                        plt.style.use('ggplot')
                        bar_width = 0.35
                    #plt.xticks([r + bar_width / 2 for r in range(len(subname))], subname)
                        r1 = [x * 3 for x in range(len(subname))]
                        r2 = [x * 3 + 1 for x in range(len(subname))]
                        r3 = [x * 3 + 2 for x in range(len(subname))]
                    
                        bar_spacing = 0.05

# set x-tick locations for each bar group
                    

                        for i in range(len(mid)):
                            num_ticks = 10
                            xtick_locations = np.arange(num_ticks) * bar_width + r2[i] - bar_width / 2
                            #if i % 3 == 0:
                                  #plt.xticks([r + bar_width for r in range(i, i+3)], subname[i:i+3])
                            if avg[i] <14:
                                plt.bar(r1[i], mid1[i], color='blue', width=bar_width, edgecolor='black', label='Mid1')
                                plt.bar(r2[i], mid2[i], color='orange', width=bar_width, edgecolor='black', label='Mid2')
                                plt.bar(r3[i], avg[i], color='red', width=bar_width, edgecolor='black', label='average')
                            else:
                                 plt.bar(r1[i], mid1[i], color='blue', width=bar_width, edgecolor='black', label='Mid1')
                                 plt.bar(r2[i], mid2[i], color='orange', width=bar_width, edgecolor='black', label='Mid2')
                                 plt.bar(r3[i], avg[i], color='green', width=bar_width, edgecolor='black', label='average')
                            plt.text(r1[i], mid1[i], str(mid1[i]), ha='center', va='bottom', fontsize=10)
                            plt.text(r2[i], mid2[i], str(mid2[i]), ha='center', va='bottom', fontsize=10)
                            plt.text(r3[i], avg[i], str(avg[i]), ha='center', va='bottom', fontsize=10)
                        plt.xlabel('Subjects')
                        plt.ylabel('Marks')
                        plt.title('Mid-term Marks')
                        plt.xticks([r*3 + bar_width+1 for r in range(len(subname))], subname)


                    

                        for i in range(0, len(subname)*3, 3):
                                plt.axvline(x=i-0.5, color='black', linewidth=3)
                        red_patch = mpatches.Patch(color='red', label='Fail')
                        blue_patch = mpatches.Patch(color='blue', label='Mid1')
                        orange_patch= mpatches.Patch(color='orange', label='Mid2')
                        green_patch= mpatches.Patch(color='green', label='good average')
                    
                        plt.legend(handles=[red_patch, blue_patch,orange_patch,green_patch], bbox_to_anchor=(1.05, 1), loc='upper left')
                        graph_file3 = 'mid_marks.png'
                        plt.savefig('C:/external/counselling/static/image/'+ graph_file3,bbox_inches='tight')
                    else:
                        graph_file3=None
         #ATTENDANCE
                    
                    percentage_attendance = y / 100.0

# calculate the percentage of absences
                    percentage_absences = 1 - percentage_attendance

# create a list of attendance and absences percentages
                    attendance_percentages = [percentage_attendance, percentage_absences]

# create a list of labels for the pie chart
                    labels = ['present', 'Absence']

# set the colors for the pie chart
                    if y>75:
                          colors = ['green', 'wheat']
                    elif y<75 and y>65:
                        colors = ['yellow', 'wheat']
                    else:
                        colors = ['red', 'wheat']


# create the pie chart
                    fig3, ax3 = plt.subplots()
                    ax3.pie(attendance_percentages, colors=colors, labels=labels, autopct='%1.1f%%', startangle=90)
                    red_patch = mpatches.Patch(color='red', label='<65%')
                    blue_patch = mpatches.Patch(color='yellow', label='<75% & >65%')
                    green_patch= mpatches.Patch(color='green', label='>75%')
                    
                    plt.legend(handles=[red_patch, blue_patch,green_patch], bbox_to_anchor=(1.05, 1), loc='upper left')
                    graph_file4 = 'attend.png'
                    f='Attendance of semester:'+" "+str(k)

                    ax3.set_title(f)
                    fig3.savefig('C:/external/counselling/static/image/'+ graph_file4,bbox_inches='tight')
                    if y<=0:
                        graph_file4=None


                    
    
                
                    return render(request, 'graphs.html', {'graph_file4':graph_file4,'graph_file3':graph_file3,'graph_file1': graph_file1,'graph_file2':graph_file2,'name':name})
                else:
                     return  render(request,'performance.html',{'email_a':email})



            else:
                return  render(request,'performance.html',{'email_a':email})
    





        else:
            return  render(request,'performance.html',{'email_a':email})
    else:
        return  render(request,'signin.html')




def allotcounsellors(request,branch,branchname,email):
    
    if "email_a" in request.session:
        email = request.session.get("email_a")
        #mycursor.execute(" from faculty where email='{email}'")

        if request.method=='POST':
            roll_no = request.POST['selectedstudents']
            #roll_no1=map(str, roll_no)
            #roll_nos=list(roll_no)

            roll_nos = roll_no.split(",")
            

            faculty=request.POST['faculty']
            try:
                conn = mysql.connector.connect(host="localhost", user="root", password="",database="studentdb")
                mycursor = conn.cursor()
                for i in roll_nos:
                  query2  = "SELECT max(semester) from students WHERE rollno = '"+i+"' "
            
                  mycursor.execute(query2)
                  result2=mycursor.fetchone()
                  query = f"UPDATE students SET faculty='{faculty}' WHERE rollno='{i}' and semester='{result2[0]}'"
                  mycursor.execute(query)
                  conn.commit()
                if query!=None:
                   return redirect('branch_counsellor',)
            except mysql.connector.Error as error:
                   print(f"Error: {error}")
                   conn.rollback()
            finally:
                if conn.is_connected():
                    mycursor.close()
                    conn.close()
            



        else:
           
            conn=mysql.connector.connect(host="localhost", user="root", password="",database="counsellingdb")
            mycursor=conn.cursor()
            
            mycursor.execute(f"select empid,firstname,lastname from faculty where branch='{branch}'")

            result=mycursor.fetchall()
            faculty=[]
        
            for x in result:
                obj=Faculty()
                obj.empid=x[0]
                name=x[1]+x[2]
                obj.name=name
                #obj.empid=x[0]
                 
                faculty.append(obj)
            conn=mysql.connector.connect(host="localhost", user="root", password="",database="counsellingdb")
            mycursor=conn.cursor()
            
           
            conn=mysql.connector.connect(host="localhost", user="root", password="",database="studentdb")
            mycursor=conn.cursor()
            
            mycursor.execute("select rollno from students where branch='"+branchname+"'")
            students=[]
            result=mycursor.fetchall()
            for x in result:
                obj=Students()
                obj.rollno=x[0]
                
                students.append(obj)
            url = reverse('allotcounsellors', kwargs={'branch': branch,'branchname':branchname, 'email': email})
        
            return render(request,'allotcounsellors.html',{'students':students,"faculty":faculty,'url': url,'email_a':email})



    else:
        return render(request, 'signin.html')




def branch_counsellor(request):
    
    if "email_a" in request.session:
        email = request.session.get("email_a")
        #mycursor.execute(" from faculty where email='{email}'")

        if request.method=='POST':
            branch=request.POST['branch']
            conn=mysql.connector.connect(host="localhost", user="root", password="", database= "counsellingdb")
            mycursor=conn.cursor()
            mycursor.execute("select branch from branches where bid='{}'".format(branch))
            result=mycursor.fetchone()
            
            obj=Branch()
            branchname=result[0]

            url = reverse('allotcounsellors', kwargs={'branch': branch,'branchname':branchname, 'email': email})
            return redirect(url)                                                                      



            


            #fname=request.POST['firstname']

        else:
            conn=mysql.connector.connect(host="localhost", user="root", password="", database= "counsellingdb")
            mycursor=conn.cursor()
            mycursor.execute("select * from branches")
            result=mycursor.fetchall()
            branches=[]  
            for x in result:
                obj=Branch()
                obj.bid=x[0]
                obj.branch=x[1]
                branches.append(obj)

           
           
            return  render(request,'branch_counsellor.html',{'branches':branches,'email_a':email})



    else:
        return render(request, 'signin.html')











def logout_a(request):
    email_a = request.session.get("email_a")
    del email_a
    request.session.modified = True
    return redirect('signin')
        
def map(request):
    return render(request,"map.html")
def graphs(request):
    return render(request,"graphs.html")
def faculty_details_table(request):
     return render(request,"faculty_details_table.html")

def faculty_details(request):
    if "email_a" in request.session:
        email = request.session.get("email_a")
        #mycursor.execute(" from faculty where email='{email}'")
        if request.method=='POST':
            
                branch1=request.POST.get('branch1',None)
                conn=mysql.connector.connect(host="localhost", user="root", password="", database="counsellingdb")
                mycursor=conn.cursor()

                if branch1!="Select Branch":
                    
                    mycursor.execute("select empid,firstname,lastname,email,phonenumber,branch,gender,roleid from faculty where branch='"+branch1+"'  ORDER BY empid")
                    result=mycursor.fetchall()
                    if result!=None:
                        
                        details = []
                        for row in result:
                                obj = Faculty()         
                                obj.empid = row[0]
                                obj.firstname = row[1]
                                obj.lastname=row[2]
                                obj.email = row[3]
                                obj.phonenumber = row[4]
                                obj.branch = row[5]
                                
                                obj.gender = row[6]
                               
                                obj.roleid = row[7]
                                
                                details.append(obj)
                
                         
                            #column_names = [column for column in column_details]
    
    # Create a list of tuples with column names and user details
                           
                        return render(request, 'faculty_details_table.html', {'details':details,'email_a':email})
                    else:
                        return render(request, 'faculty_details.html', {'email_a':email})

    
        else:    
            conn=mysql.connector.connect(host="localhost", user="root", password="", database= "counsellingdb")
            mycursor=conn.cursor()
            mycursor.execute("select * from branches")
            result=mycursor.fetchall()
            branches=[]  
            for x in result:
                obj=Branch()
                obj.bid=x[0]
                obj.branch=x[1]
                branches.append(obj)

           
           
            return  render(request,'faculty_details.html',{'branches':branches,'email_a':email})
        
          
          
    else:        

       # return render(request,"student_details_a.html")
        return render(request,"signin.html")



def dashboard_faculty(request):
    conn = mysql.connector.connect(host="localhost",
            user="root",
            password="",
            database="counsellingdb")
    if "email_f" in request.session:
        name = request.session.get("email_f")
        return render(request, 'dashboard_faculty.html', {"email_f": name})
    else:
        return render(request, 'signin.html')
def dashboard_student(request):
    conn = mysql.connector.connect(host="localhost",
            user="root",
            password="",
            database="counsellingdb")
    if "email_s" in request.session:
        name = request.session.get("email_s")
        return render(request, 'dashboard_student.html', {"email_s": name})
    else:
        return render(request, 'signin.html')
     
def icons(request):
    return render(request,"icons.html")
def login(request):
    return render(request,"login.html")
def profile(request):
    return render(request,"profile.html")
def rtl(request):
    return render(request,"rtl.html")
def typography(request):
    return render(request,"typography.html")
def alloted(request):
    if 'email_a' in request.session:
        email = request.session.get("email_a")
        conn=mysql.connector.connect(host="localhost", user="root", password="",database="counsellingdb")
        mycursor=conn.cursor()
        mycursor.execute("select empid from faculty where email=%s", (email,))
        

        result=mycursor.fetchone()
        if result!=None:
            conn=mysql.connector.connect(host="localhost", user="root", password="",database="studentdb")
            mycursor=conn.cursor()
            mycursor.execute(f"select rollno,fname,lname,email,branch,year,semester,studmob,fmob,section,attendance from students where faculty={result[0]} ORDER BY rollno")
            result=mycursor.fetchall()
            if result!=None:
                        
                        details = []
                        for row in result:
                                obj = Students()         
                                obj.rollno = row[0]
                                obj.fname = row[1]
                                obj.lname=row[2]
                                obj.email = row[3]
                                obj.branch = row[4]
                                obj.year = row[5]
                                obj.semester = row[6]
                                obj.studmob = row[7]
                                obj.fmob = row[8]
                                obj.section = row[9]
                                obj.attendance = row[10]
                                #obj.gpa = row[10]
                                
                                details.append(obj)
                        return render(request,"alloted.html",{'details':details,'email_a':email})
        else:
            return render(request,"edit_details.html",{'email_a':email})




    else:

         return render(request,"signin.html")


def tables(request):
    return render(request,"tables.html")








