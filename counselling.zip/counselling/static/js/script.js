
function validation(){
const form = document.querySelector('form');
const usernameInput = document.querySelector('#username');
const emailInput = document.querySelector('#email');
const passwordInput = document.querySelector('#password');
const confirmPasswordInput = document.querySelector('#confirm_password');
//const gender = document.querySelector('gender');



var gender=document.getElementsByName("gender");
var sgender="";
//flag=false;
for(var i=0;i<gender.length;i++){
  if(gender[i].checked==true){
   
     sgender=gender[i].value;
     break;
  }
}
if(sgender==""){

  alert('Please select the gender');
  gender.focus();
  form.reset();
  return false;

}
else{
document.getElementById("selectedgender").value=sgender;
}

  if (usernameInput.value.trim() === '') {
    alert('Please enter a username.');
    usernameInput.focus();
    form.reset();
    return false;
  }


  if (emailInput.value.trim() === '') {
    alert('Please enter an email.');
    emailInput.focus();
    form.reset();
    return false;
  }

  if (!isValidEmail(emailInput.value)) {
    alert('Please enter a valid email.');
    emailInput.focus();
    form.reset();
    return false;
  }

  if (passwordInput.value.trim() === '') {
    alert('Please enter a password.');
    passwordInput.focus();
    form.reset();
    return false;
  }

  if (confirmPasswordInput.value.trim() === '') {
    alert('Please confirm your password.');
    confirmPasswordInput.focus();
    form.reset();
    return false;
  }

  if (passwordInput.value !== confirmPasswordInput.value) {
    alert('Passwords do not match.');
    confirmPasswordInput.focus();
    form.reset();
    return false;
  }
  else{
    return true;
  }

  // Submit the form data using AJAX or other method
  // ...

  // Reset the form fields
  //form.reset();

}
function isValidEmail(email) {
  // A simple email validation function using a regular expression
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return pattern.test(email);
}

